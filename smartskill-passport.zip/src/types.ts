export interface Skill {
  id: string;
  name: string;
  category: 'technical' | 'soft';
  level: 'Beginner' | 'Intermediate' | 'Expert';
  yearsOfExperience: number;
  verified: boolean;
  certificateId?: string;
}

export interface Certificate {
  id: string;
  title: string;
  issuer: string;
  issueDate: string;
  expiryDate?: string;
  credentialUrl?: string;
  txHash: string; // Blockchain verification hash simulation
  verifiedStatus: 'Verified' | 'Pending' | 'Rejected';
  skillsRelated: string[];
}

export interface Experience {
  id: string;
  role: string;
  company: string;
  logoColor?: string;
  startDate: string;
  endDate: string; // "Present" or date
  description: string;
  skillsUsed: string[];
}

export interface Education {
  id: string;
  degree: string;
  field: string;
  school: string;
  startDate: string;
  endDate: string;
  grade?: string;
  verified: boolean;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  url?: string;
  github?: string;
  skillsUsed: string[];
}

export interface PrivacySettings {
  publicView: boolean;
  showContact: boolean;
  showAnalytics: boolean;
  allowEmployerSearch: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
  bio: string;
  headline: string;
  location: string;
  joinedDate: string;
  skills: Skill[];
  certificates: Certificate[];
  experience: Experience[];
  education: Education[];
  projects: Project[];
  privacySettings: PrivacySettings;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  date: string;
  author: string;
  category: string;
  readTime: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: string;
}
