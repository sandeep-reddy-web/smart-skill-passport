import { UserProfile, BlogPost, FAQItem } from './types';

export const SAMPLE_USERS: UserProfile[] = [
  {
    id: 'user-1',
    name: 'Elena Rostova',
    email: 'elena.r@cloudops.io',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200',
    headline: 'Senior Cloud Architect & DevSecOps Engineer',
    location: 'Seattle, WA (Remote)',
    bio: 'Passionate Systems Engineer specializing in highly-available Kubernetes deployments, multi-region AWS cloud strategy, and zero-trust security compliance. 8+ years building robust backend architectures and mentoring engineering teams.',
    joinedDate: '2024-03-15',
    skills: [
      { id: 's1', name: 'Kubernetes & AWS', category: 'technical', level: 'Expert', yearsOfExperience: 6, verified: true },
      { id: 's2', name: 'Terraform (IaC)', category: 'technical', level: 'Expert', yearsOfExperience: 5, verified: true },
      { id: 's3', name: 'Docker', category: 'technical', level: 'Expert', yearsOfExperience: 7, verified: true },
      { id: 's4', name: 'Golang', category: 'technical', level: 'Intermediate', yearsOfExperience: 3, verified: false },
      { id: 's5', name: 'Node.js & TypeScript', category: 'technical', level: 'Expert', yearsOfExperience: 5, verified: true },
      { id: 's6', name: 'System Architecture', category: 'technical', level: 'Expert', yearsOfExperience: 8, verified: true },
      { id: 's7', name: 'Technical Leadership', category: 'soft', level: 'Expert', yearsOfExperience: 4, verified: true },
      { id: 's8', name: 'Agile Project Management', category: 'soft', level: 'Intermediate', yearsOfExperience: 6, verified: false }
    ],
    certificates: [
      {
        id: 'cert-101',
        title: 'AWS Certified Solutions Architect – Professional',
        issuer: 'Amazon Web Services (AWS)',
        issueDate: '2025-01-20',
        expiryDate: '2028-01-20',
        credentialUrl: 'https://aws.amazon.com/verification/9a8b7c6d5e4f',
        txHash: '0x8f3c7d9a1e0b5c4f2a7d8e9c0b1a2e3f4c5b6a7d8e9f0a1b2c3d4e5f6a7b8c9d',
        verifiedStatus: 'Verified',
        skillsRelated: ['Kubernetes & AWS', 'System Architecture']
      },
      {
        id: 'cert-102',
        title: 'Certified Kubernetes Administrator (CKA)',
        issuer: 'The Linux Foundation (CNCF)',
        issueDate: '2024-08-10',
        expiryDate: '2027-08-10',
        credentialUrl: 'https://verify.linuxfoundation.org/cka/102-392-491',
        txHash: '0x4f8e7c2a1d0b5e9f3c7a8b9d0e1f2a3c4b5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f',
        verifiedStatus: 'Verified',
        skillsRelated: ['Kubernetes & AWS', 'Docker']
      },
      {
        id: 'cert-103',
        title: 'HashiCorp Certified: Terraform Associate',
        issuer: 'HashiCorp',
        issueDate: '2025-05-14',
        txHash: '0x2c9b1a0e8d7f6c5b4a3e2d1c0b9a8f7e6d5c4b3a2f1e0d9c8b7a6f5e4d3c2b1a',
        verifiedStatus: 'Verified',
        skillsRelated: ['Terraform (IaC)']
      }
    ],
    experience: [
      {
        id: 'exp-1',
        role: 'Lead Cloud Infrastructure Architect',
        company: 'CloudOps Solutions Inc.',
        logoColor: 'from-blue-500 to-indigo-600',
        startDate: '2023-05',
        endDate: 'Present',
        description: 'Pioneered migration of 40+ legacy services into high-performance AWS EKS cluster, slashing cloud operational expenditures by 34%. Spearheaded transition to GitOps with ArgoCD and Terraform Enterprise across a 25-person dev team.',
        skillsUsed: ['Kubernetes & AWS', 'Terraform (IaC)', 'System Architecture', 'Technical Leadership']
      },
      {
        id: 'exp-2',
        role: 'Senior DevOps Security Specialist',
        company: 'Apex Guard Systems',
        logoColor: 'from-emerald-500 to-teal-600',
        startDate: '2021-02',
        endDate: '2023-04',
        description: 'Engineered automatic vulnerability checking pipelines (Trivy, SonarQube) scanning 120+ repositories, blocking potential software defects before production deployment. Established secure secret management frameworks utilizing HashiCorp Vault.',
        skillsUsed: ['Docker', 'Node.js & TypeScript', 'Terraform (IaC)']
      }
    ],
    education: [
      {
        id: 'edu-1',
        degree: 'Master of Science in Cybersecurity & Distributed Systems',
        field: 'Computer Science',
        school: 'University of Washington',
        startDate: '2018-09',
        endDate: '2020-06',
        grade: '3.92 GPA',
        verified: true
      },
      {
        id: 'edu-2',
        degree: 'Bachelor of Science in Software Engineering',
        field: 'Software Engineering',
        school: 'Boston University',
        startDate: '2014-09',
        endDate: '2018-05',
        verified: true
      }
    ],
    projects: [
      {
        id: 'proj-1',
        title: 'Zero-Trust EKS Framework',
        description: 'An open-source Terraform blueprint implementing absolute network segregation, automated IAM authentication, and eBPF network monitoring with Cilium for EKS clusters.',
        github: 'github.com/elenar/zerotrust-eks-tf',
        skillsUsed: ['Kubernetes & AWS', 'Terraform (IaC)', 'System Architecture']
      },
      {
        id: 'proj-2',
        title: 'GoKube-Scaler',
        description: 'Custom Kubernetes horizontal pod autoscaler controller written in Golang, triggering instant cluster elasticity based on custom network telemetry metrics.',
        github: 'github.com/elenar/gokube-scaler',
        skillsUsed: ['Golang', 'Kubernetes & AWS', 'Docker']
      }
    ],
    privacySettings: {
      publicView: true,
      showContact: true,
      showAnalytics: true,
      allowEmployerSearch: true
    }
  },
  {
    id: 'user-2',
    name: 'Liam Chen',
    email: 'liam.chen@pixelcraft.dev',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
    headline: 'Creative UX Engineer & Front-End Specialist',
    location: 'San Francisco, CA (Hybrid)',
    bio: 'Bridging the design-engineering divide by designing beautiful visual systems and executing them into accessible, light-speed, motion-rich React applications. Creative developer dedicated to absolute typographic precision and fluid UI interactions.',
    joinedDate: '2024-06-22',
    skills: [
      { id: 's201', name: 'React & Next.js', category: 'technical', level: 'Expert', yearsOfExperience: 5, verified: true },
      { id: 's202', name: 'Tailwind CSS', category: 'technical', level: 'Expert', yearsOfExperience: 6, verified: true },
      { id: 's203', name: 'UI/UX Interactive Prototyping', category: 'technical', level: 'Expert', yearsOfExperience: 6, verified: true },
      { id: 's204', name: 'Framer Motion', category: 'technical', level: 'Expert', yearsOfExperience: 4, verified: true },
      { id: 's205', name: 'WebGL & Three.js', category: 'technical', level: 'Intermediate', yearsOfExperience: 2, verified: false },
      { id: 's206', name: 'Figma to Code Pipeline', category: 'technical', level: 'Expert', yearsOfExperience: 5, verified: true },
      { id: 's207', name: 'Collaboration & Communication', category: 'soft', level: 'Expert', yearsOfExperience: 7, verified: true },
      { id: 's208', name: 'Creative Typography', category: 'soft', level: 'Expert', yearsOfExperience: 5, verified: true }
    ],
    certificates: [
      {
        id: 'cert-201',
        title: 'Google UX Design Professional Certificate',
        issuer: 'Google Career Certificates',
        issueDate: '2023-11-05',
        credentialUrl: 'https://coursera.org/verify/googleuxliamchen',
        txHash: '0xda3f4c5b6a7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3c4b5d6e7f8a9b0c1d2e3f',
        verifiedStatus: 'Verified',
        skillsRelated: ['UI/UX Interactive Prototyping', 'Figma to Code Pipeline']
      },
      {
        id: 'cert-202',
        title: 'Meta Front-End Developer Capstone Honors',
        issuer: 'Meta Engineering',
        issueDate: '2024-02-18',
        txHash: '0x9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f9a8b',
        verifiedStatus: 'Verified',
        skillsRelated: ['React & Next.js', 'Tailwind CSS']
      }
    ],
    experience: [
      {
        id: 'exp-3',
        role: 'Senior Interactive Front-End Architect',
        company: 'PixelCraft Studios',
        logoColor: 'from-purple-500 to-pink-600',
        startDate: '2023-10',
        endDate: 'Present',
        description: 'Building next-generation design systems and highly-interactive marketing landing experiences for Fortune 500 SaaS companies. Refined Figma-to-React development pipelines, increasing overall layout delivery speed by 40%.',
        skillsUsed: ['React & Next.js', 'Tailwind CSS', 'Framer Motion', 'Figma to Code Pipeline']
      },
      {
        id: 'exp-4',
        role: 'UX Prototyping Engineer',
        company: 'Vortex Tech',
        logoColor: 'from-orange-500 to-amber-600',
        startDate: '2021-06',
        endDate: '2023-09',
        description: 'Designed high-fidelity mockups and translated interactive dashboards into accessible HTML/CSS components. Maintained Web Content Accessibility Guidelines (WCAG) 2.1 compliance across all global customer platforms.',
        skillsUsed: ['UI/UX Interactive Prototyping', 'React & Next.js', 'Tailwind CSS', 'Collaboration & Communication']
      }
    ],
    education: [
      {
        id: 'edu-3',
        degree: 'Bachelor of Fine Arts in Interaction Design',
        field: 'Interaction Design',
        school: 'California College of the Arts',
        startDate: '2017-09',
        endDate: '2021-05',
        grade: '3.88 GPA',
        verified: true
      }
    ],
    projects: [
      {
        id: 'proj-3',
        title: 'MotionCanvas UI Toolkit',
        description: 'An open-source library of highly accessible, fluid, copy-paste Tailwind UI components powered by Framer Motion, optimized for smooth layout transitions.',
        github: 'github.com/liamchen/motioncanvas-ui',
        skillsUsed: ['React & Next.js', 'Tailwind CSS', 'Framer Motion']
      },
      {
        id: 'proj-4',
        title: '3D Portfolio Studio',
        description: 'Immersive WebGL based interactive portfolio displaying credentials in an abstract architectural virtual space, complete with dynamic lighting grids.',
        github: 'github.com/liamchen/3d-portfolio',
        skillsUsed: ['WebGL & Three.js', 'Framer Motion', 'React & Next.js']
      }
    ],
    privacySettings: {
      publicView: true,
      showContact: true,
      showAnalytics: true,
      allowEmployerSearch: true
    }
  },
  {
    id: 'user-3',
    name: 'Sarah Jenkins',
    email: 'sarah.j@cognitivesystems.ai',
    avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200',
    headline: 'Machine Learning Research Engineer & Data Architect',
    location: 'Austin, TX (Remote)',
    bio: 'Data Scientist specializing in large-scale machine learning modeling, natural language processing, and deep neural networks. Passionate about AI safety, vector search indexes, and compiling raw big-data sets into clean, decision-making pipelines.',
    joinedDate: '2024-01-08',
    skills: [
      { id: 's301', name: 'Python & PyTorch', category: 'technical', level: 'Expert', yearsOfExperience: 6, verified: true },
      { id: 's302', name: 'Machine Learning Modeling', category: 'technical', level: 'Expert', yearsOfExperience: 5, verified: true },
      { id: 's303', name: 'Big Data (Spark, SQL)', category: 'technical', level: 'Expert', yearsOfExperience: 5, verified: true },
      { id: 's304', name: 'Data Visualization & D3', category: 'technical', level: 'Expert', yearsOfExperience: 4, verified: true },
      { id: 's305', name: 'Large Language Models (LLM)', category: 'technical', level: 'Intermediate', yearsOfExperience: 3, verified: true },
      { id: 's306', name: 'NLP Transformers', category: 'technical', level: 'Intermediate', yearsOfExperience: 3, verified: false },
      { id: 's307', name: 'Analytical Thinking', category: 'soft', level: 'Expert', yearsOfExperience: 8, verified: true },
      { id: 's308', name: 'Scientific Writing', category: 'soft', level: 'Expert', yearsOfExperience: 4, verified: true }
    ],
    certificates: [
      {
        id: 'cert-301',
        title: 'Deep Learning Specialization',
        issuer: 'DeepLearning.AI',
        issueDate: '2023-05-12',
        credentialUrl: 'https://coursera.org/verify/deeplearningjsarahlj',
        txHash: '0x1c2b3a4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b',
        verifiedStatus: 'Verified',
        skillsRelated: ['Machine Learning Modeling', 'Python & PyTorch']
      },
      {
        id: 'cert-302',
        title: 'Databricks Certified Data Engineer Professional',
        issuer: 'Databricks Academy',
        issueDate: '2024-10-30',
        txHash: '0xe8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9',
        verifiedStatus: 'Verified',
        skillsRelated: ['Big Data (Spark, SQL)']
      }
    ],
    experience: [
      {
        id: 'exp-5',
        role: 'Senior Machine Learning Scientist',
        company: 'Cognitive Systems AI',
        logoColor: 'from-rose-500 to-orange-600',
        startDate: '2023-01',
        endDate: 'Present',
        description: 'Formulated high-speed multi-modal search pipelines mapping unstructured corporate wikis into Vector DB collections, elevating internal document search relevance by 55%. Optimized training runs of 7B param LLM models, halving compute budgets.',
        skillsUsed: ['Python & PyTorch', 'Machine Learning Modeling', 'Large Language Models (LLM)', 'Analytical Thinking']
      },
      {
        id: 'exp-6',
        role: 'Data Science Analyst',
        company: 'HealthIQ Analytics',
        logoColor: 'from-blue-600 to-sky-500',
        startDate: '2020-08',
        endDate: '2022-12',
        description: 'Analyzed clinical test profiles for automated predictive medical screening pipelines. Programmed interactive big-data reporting widgets with D3.js and Spark, enabling doctors to monitor high-risk patient health indexes.',
        skillsUsed: ['Big Data (Spark, SQL)', 'Data Visualization & D3', 'Python & PyTorch', 'Analytical Thinking']
      }
    ],
    education: [
      {
        id: 'edu-4',
        degree: 'Bachelor of Science in Mathematics & Statistics',
        field: 'Mathematics',
        school: 'University of Texas at Austin',
        startDate: '2016-09',
        endDate: '2020-05',
        grade: '3.97 GPA',
        verified: true
      }
    ],
    projects: [
      {
        id: 'proj-5',
        title: 'CognitiveSearch LLM Engine',
        description: 'An intelligent semantic vector document scanner retrieving related paragraphs inside large PDF folders, complete with source verification flags.',
        github: 'github.com/sarahj/cognitive-search',
        skillsUsed: ['Python & PyTorch', 'Large Language Models (LLM)', 'Machine Learning Modeling']
      },
      {
        id: 'proj-6',
        title: 'Dynamic D3 Metric Hub',
        description: 'High performance real-time sensor visualization matrix using pure React + D3.js, rendering over 10,000 active telemetry streams at 60fps.',
        github: 'github.com/sarahj/d3-metric-hub',
        skillsUsed: ['Data Visualization & D3', 'Python & PyTorch']
      }
    ],
    privacySettings: {
      publicView: true,
      showContact: true,
      showAnalytics: true,
      allowEmployerSearch: true
    }
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'post-1',
    title: 'The Shift to Verifiable Portability: Why Traditional Resumes are Dying',
    excerpt: 'How blockchain-verified, cryptographically stamped skill passports are replacing paper PDFs to eradicate credentials fraud and fast-track hiring workflows.',
    date: '2026-06-12',
    author: 'Dr. Evelyn Carter',
    category: 'Industry Trends',
    readTime: '6 min read'
  },
  {
    id: 'post-2',
    title: 'Understanding Decentralized Identification (DIDs) for Software Engineers',
    excerpt: 'An in-depth technical deep dive into W3C DID specifications and how they allow engineers to retain total authority over their professional credentials and badges.',
    date: '2026-07-01',
    author: 'Marcus Vance, Tech Lead',
    category: 'Technology',
    readTime: '8 min read'
  },
  {
    id: 'post-3',
    title: 'How to Build and Showcase a Verifiable Proof-of-Skill Portfolio',
    excerpt: 'Actionable tactics to tie github projects, certificate credentials, and endorsements to specific verifiable blocks on your professional Smart Passport.',
    date: '2026-07-15',
    author: 'Elena Rostova',
    category: 'Career Advice',
    readTime: '5 min read'
  }
];

export const FAQ_ITEMS: FAQItem[] = [
  {
    category: 'General',
    question: 'What is a Smart Skill Passport?',
    answer: 'A Smart Skill Passport is an immutable, portable, and secure digital identity displaying your professional competencies, certified badges, education, and career milestones. Every credential added is cryptographically secured (simulated via blockchain verification hashes), making it easily shareable and instantly trustable.'
  },
  {
    category: 'Verification',
    question: 'How does the certification validation system work?',
    answer: 'When you upload a certificate or link a credential, our system validates the issuer identity and stamps the transaction into an immutable ledger (simulated on-chain). Third-party recruiters can instantly scan your unique QR code or click your verifiable passport URL to see authenticated timestamps, certificate signatures, and corresponding transaction logs.'
  },
  {
    category: 'Privacy',
    question: 'Do I have control over which details are public?',
    answer: 'Absolutely. Built with privacy-first standards, you have detailed granular control. You can turn your public view on/off, choose whether to show direct contact methods, toggle allowability in employer skill search directories, and limit analytics insights to your personal view.'
  },
  {
    category: 'For Employers',
    question: 'How do employers verify skills on this platform?',
    answer: 'Recruiters can utilize our "Employer Search" engine to filter professionals by specific skills, competency level, and badge verification. Because skills are tied to verified credentials with cryptographic proof hashes, hiring managers can skip long verification delays and confidently short-list candidates.'
  }
];
