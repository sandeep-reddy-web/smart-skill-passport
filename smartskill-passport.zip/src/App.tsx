import React, { useState, useEffect } from 'react';
import { ShieldCheck, LogIn, Mail, Lock, User, Plus, Compass, Briefcase, Award, ArrowRight, HelpCircle, FileText } from 'lucide-react';
import { UserProfile, Skill } from './types';
import { SAMPLE_USERS } from './data';
import Navigation from './components/Navigation';
import LandingPage from './components/LandingPage';
import PassportDisplay from './components/PassportDisplay';
import Dashboard from './components/Dashboard';
import EmployerPortal from './components/EmployerPortal';
import VerificationCenter from './components/VerificationCenter';
import StaticPages from './components/StaticPages';

export default function App() {
  const [currentView, setCurrentView] = useState<string>('landing');
  const [staticSubTab, setStaticSubTab] = useState<'about' | 'pricing' | 'blog' | 'faq' | 'contact'>('about');
  
  // Auth state
  const [user, setUser] = useState<UserProfile | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authTab, setAuthTab] = useState<'signin' | 'signup'>('signin');

  // Directory users pool (SAMPLE_USERS + custom registered user)
  const [allUsers, setAllUsers] = useState<UserProfile[]>(SAMPLE_USERS);
  
  // Active passport being previewed by an employer
  const [activePreviewUser, setActivePreviewUser] = useState<UserProfile | null>(null);

  // Form states for login/signup
  const [authName, setAuthName] = useState('');
  const [authEmail, setAuthEmail] = useState('');
  const [authHeadline, setAuthHeadline] = useState('');
  const [authPassword, setAuthPassword] = useState('');
  const [authError, setAuthError] = useState('');

  // Load user session on boot
  useEffect(() => {
    const savedUser = localStorage.getItem('ssp_logged_in_user');
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser) as UserProfile;
        setUser(parsedUser);
        
        // Sync custom user into allUsers pool
        setAllUsers(prev => {
          const filtered = prev.filter(u => u.id !== parsedUser.id);
          return [parsedUser, ...filtered];
        });
      } catch (e) {
        console.error("Failed to restore session:", e);
      }
    }
  }, []);

  // Sync user state changes to localStorage and search index pool
  const handleUpdateUser = (updatedProfile: UserProfile) => {
    setUser(updatedProfile);
    localStorage.setItem('ssp_logged_in_user', JSON.stringify(updatedProfile));
    
    // Update pool
    setAllUsers(prev => {
      const filtered = prev.filter(u => u.id !== updatedProfile.id);
      return [updatedProfile, ...filtered];
    });
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('ssp_logged_in_user');
    setCurrentView('landing');
  };

  const handleViewDemoAccount = () => {
    // Populate Liam Chen as the logged-in demo user
    const liam = SAMPLE_USERS.find(u => u.id === 'user-2') || SAMPLE_USERS[0];
    setUser(liam);
    localStorage.setItem('ssp_logged_in_user', JSON.stringify(liam));
    setCurrentView('dashboard');
    setShowAuthModal(false);
  };

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');

    if (authTab === 'signin') {
      // Demo SignIn verification
      if (!authEmail || !authPassword) {
        setAuthError('Please fill in all credentials.');
        return;
      }

      // If they type a sample user, log them in as them!
      const matchedSample = SAMPLE_USERS.find(u => u.email.toLowerCase() === authEmail.toLowerCase().trim());
      if (matchedSample) {
        setUser(matchedSample);
        localStorage.setItem('ssp_logged_in_user', JSON.stringify(matchedSample));
        setCurrentView('dashboard');
        setShowAuthModal(false);
        resetAuthForms();
        return;
      }

      // Otherwise, check if they registered before
      const savedUser = localStorage.getItem('ssp_logged_in_user');
      if (savedUser) {
        try {
          const parsed = JSON.parse(savedUser) as UserProfile;
          if (parsed.email.toLowerCase() === authEmail.toLowerCase().trim()) {
            setUser(parsed);
            setCurrentView('dashboard');
            setShowAuthModal(false);
            resetAuthForms();
            return;
          }
        } catch (e) {}
      }

      // Fallback: Create custom fresh profile instantly for ease of use
      const freshUser: UserProfile = {
        id: `custom-user-${Date.now()}`,
        name: authEmail.split('@')[0],
        email: authEmail.trim(),
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200',
        headline: 'Innovative Engineer',
        location: 'Global (Remote)',
        bio: 'Onboarding professional building a verifiable skill portfolio.',
        joinedDate: new Date().toISOString().split('T')[0],
        skills: [
          { id: 'cs-1', name: 'Software Engineering', category: 'technical', level: 'Intermediate', yearsOfExperience: 3, verified: false }
        ],
        certificates: [],
        experience: [],
        education: [],
        projects: [],
        privacySettings: {
          publicView: true,
          showContact: true,
          showAnalytics: true,
          allowEmployerSearch: true
        }
      };
      setUser(freshUser);
      localStorage.setItem('ssp_logged_in_user', JSON.stringify(freshUser));
      setCurrentView('dashboard');
      setShowAuthModal(false);
      resetAuthForms();

    } else {
      // SignUp Flow
      if (!authName || !authEmail || !authHeadline) {
        setAuthError('Please fill in all registration fields.');
        return;
      }

      const newUser: UserProfile = {
        id: `custom-user-${Date.now()}`,
        name: authName.trim(),
        email: authEmail.trim(),
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
        headline: authHeadline.trim(),
        location: 'United States (Remote)',
        bio: 'Self-sovereign digital professional. Connect with me to view verified certificates and experience blocks.',
        joinedDate: new Date().toISOString().split('T')[0],
        skills: [
          { id: 'cs-1', name: 'Problem Solving', category: 'soft', level: 'Expert', yearsOfExperience: 5, verified: false }
        ],
        certificates: [],
        experience: [],
        education: [],
        projects: [],
        privacySettings: {
          publicView: true,
          showContact: true,
          showAnalytics: true,
          allowEmployerSearch: true
        }
      };

      setUser(newUser);
      localStorage.setItem('ssp_logged_in_user', JSON.stringify(newUser));
      
      // Update pool
      setAllUsers(prev => [newUser, ...prev]);

      setCurrentView('dashboard');
      setShowAuthModal(false);
      resetAuthForms();
    }
  };

  const resetAuthForms = () => {
    setAuthName('');
    setAuthEmail('');
    setAuthHeadline('');
    setAuthPassword('');
    setAuthError('');
  };

  // Quick navigate to static subtabs (FAQ, Pricing etc)
  const navigateToStatic = (subTabId: 'about' | 'pricing' | 'blog' | 'faq' | 'contact') => {
    setStaticSubTab(subTabId);
    setCurrentView('about');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="flex flex-col min-h-screen bg-slate-50 font-sans" id="app-root">
      
      {/* Header / Nav */}
      <Navigation
        currentView={currentView}
        setCurrentView={setCurrentView}
        user={user}
        onLogout={handleLogout}
        onOpenAuthModal={() => {
          setAuthTab('signin');
          setShowAuthModal(true);
        }}
        onViewDemo={handleViewDemoAccount}
      />

      {/* Main Container */}
      <main className="flex-grow" id="main-content-layout">
        
        {currentView === 'landing' && (
          <LandingPage
            onStartOnboarding={() => {
              setAuthTab('signup');
              setShowAuthModal(true);
            }}
            onExploreFeatures={() => navigateToStatic('about')}
            onEmployerSearch={() => setCurrentView('search')}
            onViewDemo={handleViewDemoAccount}
          />
        )}

        {currentView === 'dashboard' && user && (
          <Dashboard
            user={user}
            onUpdateUser={handleUpdateUser}
          />
        )}

        {currentView === 'search' && (
          <EmployerPortal
            allUsers={allUsers}
            onViewPassport={(previewUser) => {
              setActivePreviewUser(previewUser);
              setCurrentView('passport-preview');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentView === 'verify' && (
          <VerificationCenter allUsers={allUsers} />
        )}

        {currentView === 'about' && (
          <StaticPages initialSubTab={staticSubTab} />
        )}

        {currentView === 'passport-preview' && activePreviewUser && (
          <div className="bg-slate-50 min-h-screen py-6" id="preview-outer-container">
            <div className="max-w-5xl mx-auto px-4 flex justify-between items-center mb-4" id="preview-sub-header">
              <button
                onClick={() => {
                  setCurrentView('search');
                  setActivePreviewUser(null);
                }}
                className="px-4 py-2 bg-white text-slate-700 hover:bg-slate-100 border border-slate-200 text-xs font-semibold rounded-lg shadow-sm"
              >
                ← Back to Talent Directory
              </button>
              <div className="text-xs font-mono text-emerald-600 font-bold bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100 flex items-center">
                ● Examining Authentic Credentials
              </div>
            </div>
            <PassportDisplay profile={activePreviewUser} isOwnProfile={user?.id === activePreviewUser.id} onEditToggle={() => setCurrentView('dashboard')} />
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-12 border-t border-slate-800" id="global-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
            
            {/* Column 1 Logo */}
            <div className="md:col-span-4 space-y-4" id="footer-col-1">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-md">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <span className="font-sans font-bold text-base text-white tracking-tight">SmartSkill Passport</span>
              </div>
              <p className="text-xs text-slate-500 font-sans leading-relaxed">
                A secure digital credential tracking portal built to eliminate recruitment credential fraud and empower self-sovereign professionals.
              </p>
              <div className="text-[10px] font-mono text-slate-600">
                Secured via Decentralized Stamp Ledger
              </div>
            </div>

            {/* Column 2 Navigation shortcuts */}
            <div className="md:col-span-2 space-y-3" id="footer-col-2">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Product</h4>
              <ul className="space-y-1.5 text-xs">
                <li><button onClick={() => setCurrentView('landing')} className="hover:text-white">Landing Home</button></li>
                <li><button onClick={() => { if (user) { setCurrentView('dashboard'); } else { setShowAuthModal(true); } }} className="hover:text-white">My Passport</button></li>
                <li><button onClick={() => setCurrentView('search')} className="hover:text-white">Employer Search</button></li>
                <li><button onClick={() => setCurrentView('verify')} className="hover:text-white">Verification Hub</button></li>
              </ul>
            </div>

            {/* Column 3 Resources */}
            <div className="md:col-span-2 space-y-3" id="footer-col-3">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Resources</h4>
              <ul className="space-y-1.5 text-xs">
                <li><button onClick={() => navigateToStatic('about')} className="hover:text-white">How It Works</button></li>
                <li><button onClick={() => navigateToStatic('blog')} className="hover:text-white">Blog Articles</button></li>
                <li><button onClick={() => navigateToStatic('faq')} className="hover:text-white">Help & FAQ</button></li>
              </ul>
            </div>

            {/* Column 4 Corporate */}
            <div className="md:col-span-2 space-y-3" id="footer-col-4">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">Corporate</h4>
              <ul className="space-y-1.5 text-xs">
                <li><button onClick={() => navigateToStatic('pricing')} className="hover:text-white">Pricing Plans</button></li>
                <li><button onClick={() => navigateToStatic('about')} className="hover:text-white">B2B For Employers</button></li>
                <li><button onClick={() => navigateToStatic('contact')} className="hover:text-white">Partnership Support</button></li>
              </ul>
            </div>

            {/* Column 5 Security status */}
            <div className="md:col-span-2 space-y-3" id="footer-col-5">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">System Integrity</h4>
              <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-800/60 text-center space-y-2">
                <span className="inline-flex items-center text-[9px] font-bold text-emerald-500 font-mono">● LEDGER HEALTHY</span>
                <p className="text-[10px] text-slate-500 font-sans">Blocks dynamically secure and synchronized in UTC real-time.</p>
              </div>
            </div>

          </div>

          <div className="mt-8 pt-8 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-600" id="footer-bottom">
            <span>© 2026 SmartSkill Passport Inc. All rights reserved. Self-sovereign digital certificates.</span>
            <div className="flex space-x-4 mt-2 sm:mt-0">
              <button className="hover:underline">Privacy Policy</button>
              <button className="hover:underline">Terms of Service</button>
            </div>
          </div>
        </div>
      </footer>

      {/* GLOBAL AUTHENTICATION MODAL */}
      {showAuthModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4" id="auth-modal-overlay">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 p-6 sm:p-8 space-y-6 shadow-2xl relative" id="auth-modal-container">
            
            {/* Close Button */}
            <button
              onClick={() => {
                resetAuthForms();
                setShowAuthModal(false);
              }}
              className="absolute right-4 top-4 p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-50"
            >
              ✕
            </button>

            {/* Header branding */}
            <div className="text-center space-y-1">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-md mx-auto">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-sans font-extrabold text-slate-900">Secure Passport Wallet</h3>
              <p className="text-xs text-slate-500">Own your skills and certified qualifications</p>
            </div>

            {/* Auth Tab switches */}
            <div className="flex border-b border-slate-200">
              <button
                onClick={() => { setAuthTab('signin'); setAuthError(''); }}
                className={`flex-1 py-2 text-xs font-bold border-b-2 text-center transition-all ${authTab === 'signin' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400'}`}
              >
                Sign In
              </button>
              <button
                onClick={() => { setAuthTab('signup'); setAuthError(''); }}
                className={`flex-1 py-2 text-xs font-bold border-b-2 text-center transition-all ${authTab === 'signup' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400'}`}
              >
                Register Passport
              </button>
            </div>

            {/* Error alerts */}
            {authError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-xs font-medium">
                {authError}
              </div>
            )}

            {/* Auth Form */}
            <form onSubmit={handleAuthSubmit} className="space-y-4">
              
              {authTab === 'signup' && (
                <>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 flex items-center">
                      <User className="w-3.5 h-3.5 mr-1 text-slate-400" />
                      Your Full Name
                    </label>
                    <input
                      type="text"
                      placeholder="Elena Rostova"
                      value={authName}
                      onChange={(e) => setAuthName(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                      required
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700 flex items-center">
                      <Award className="w-3.5 h-3.5 mr-1 text-slate-400" />
                      Professional Headline
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Senior Cloud Architect & DevSecOps"
                      value={authHeadline}
                      onChange={(e) => setAuthHeadline(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                      required
                    />
                  </div>
                </>
              )}

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 flex items-center">
                  <Mail className="w-3.5 h-3.5 mr-1 text-slate-400" />
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="elena.r@cloudops.io"
                  value={authEmail}
                  onChange={(e) => setAuthEmail(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                  required
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 flex items-center">
                  <Lock className="w-3.5 h-3.5 mr-1 text-slate-400" />
                  Passport Security PIN / Password
                </label>
                <input
                  type="password"
                  placeholder="••••••••"
                  value={authPassword}
                  onChange={(e) => setAuthPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                  required={authTab === 'signin'}
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-sm flex items-center justify-center space-x-2 transition-all"
                id="auth-submit-action-btn"
              >
                <span>{authTab === 'signin' ? 'Sign In' : 'Generate Passport Key'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>

            {/* Quick Demo Access Trigger */}
            <div className="pt-4 border-t border-slate-100 space-y-3">
              <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block text-center font-bold">OR EXPLORE WITH ONE CLICK</span>
              <button
                onClick={handleViewDemoAccount}
                className="w-full py-2 border border-indigo-200 bg-indigo-50/50 hover:bg-indigo-50 text-indigo-700 text-xs font-bold rounded-lg transition-all"
                id="auth-quick-demo-btn"
              >
                Load Prepopulated Demo Passport
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
