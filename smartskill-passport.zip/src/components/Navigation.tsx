import React, { useState } from 'react';
import { ShieldCheck, Award, Search, Menu, X, LogIn, LogOut, User, Cpu, BookOpen } from 'lucide-react';
import { UserProfile } from '../types';

interface NavigationProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  user: UserProfile | null;
  onLogout: () => void;
  onOpenAuthModal: () => void;
  onViewDemo: () => void;
}

export default function Navigation({
  currentView,
  setCurrentView,
  user,
  onLogout,
  onOpenAuthModal,
  onViewDemo
}: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'landing', label: 'Home', icon: Cpu },
    { id: 'dashboard', label: 'My Passport', icon: ShieldCheck, requiresAuth: true },
    { id: 'search', label: 'Employer Search', icon: Search },
    { id: 'verify', label: 'Verification Center', icon: Award },
    { id: 'about', label: 'How It Works', icon: BookOpen },
  ];

  const handleNavClick = (viewId: string) => {
    if (viewId === 'dashboard' && !user) {
      onOpenAuthModal();
    } else {
      setCurrentView(viewId);
    }
    setMobileMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-40 w-full bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm" id="main-nav">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          {/* Logo */}
          <div className="flex items-center cursor-pointer" onClick={() => setCurrentView('landing')} id="nav-logo-container">
            <div className="flex items-center justify-center w-10 h-10 rounded-xl bg-indigo-600 text-white shadow-md shadow-indigo-100" id="nav-logo-icon">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div className="ml-3" id="nav-brand-text">
              <span className="font-sans font-bold text-lg tracking-tight text-slate-900">SmartSkill</span>
              <span className="ml-1 px-1.5 py-0.5 rounded text-[10px] font-semibold tracking-wider uppercase bg-indigo-50 text-indigo-700 border border-indigo-100">Passport</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1" id="nav-desktop-links">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id || (item.id === 'about' && ['about', 'pricing', 'blog', 'faq', 'contact'].includes(currentView));
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  id={`nav-item-${item.id}`}
                  className={`flex items-center px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                    isActive
                      ? 'bg-indigo-50 text-indigo-700'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Icon className="w-4.5 h-4.5 mr-2" />
                  {item.label}
                </button>
              );
            })}
          </div>

          {/* User Section (Desktop) */}
          <div className="hidden md:flex items-center space-x-3" id="nav-desktop-auth">
            {user ? (
              <div className="flex items-center space-x-4" id="nav-auth-user">
                <button
                  onClick={() => handleNavClick('dashboard')}
                  className="flex items-center space-x-2.5 p-1 px-3 rounded-full hover:bg-slate-50 border border-slate-100 transition-all duration-200 group"
                  id="nav-user-profile-button"
                >
                  <img
                    src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100'}
                    alt={user.name}
                    referrerPolicy="no-referrer"
                    className="w-7 h-7 rounded-full object-cover ring-2 ring-indigo-100 group-hover:ring-indigo-300 transition-all"
                  />
                  <span className="text-sm font-semibold text-slate-700 group-hover:text-slate-900">{user.name.split(' ')[0]}</span>
                </button>
                <button
                  onClick={onLogout}
                  className="p-2 rounded-lg text-slate-500 hover:text-rose-600 hover:bg-rose-50 transition-all duration-200"
                  title="Sign Out"
                  id="nav-logout-btn"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-2" id="nav-auth-anonymous">
                <button
                  onClick={onViewDemo}
                  className="text-xs font-semibold px-3 py-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-all"
                  id="nav-demo-btn"
                >
                  Quick Demo Account
                </button>
                <button
                  onClick={onOpenAuthModal}
                  className="flex items-center text-sm font-semibold px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-sm hover:shadow transition-all duration-200"
                  id="nav-login-btn"
                >
                  <LogIn className="w-4 h-4 mr-1.5" />
                  Sign In
                </button>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center" id="nav-mobile-trigger-container">
            {!user && (
              <button
                onClick={onViewDemo}
                className="mr-2 text-[10px] font-bold px-2 py-1 text-indigo-600 border border-indigo-200 rounded bg-indigo-50/50"
                id="nav-mobile-demo-btn"
              >
                Demo
              </button>
            )}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-500 hover:bg-slate-50 focus:outline-none"
              id="nav-mobile-hamburger"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-100 bg-white" id="nav-mobile-drawer">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center w-full px-4 py-3 rounded-lg text-base font-medium transition-all ${
                    isActive
                      ? 'bg-indigo-50 text-indigo-700'
                      : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                  id={`nav-mobile-item-${item.id}`}
                >
                  <Icon className="w-5 h-5 mr-3" />
                  {item.label}
                </button>
              );
            })}
          </div>

          <div className="pt-4 pb-4 border-t border-slate-100 px-4" id="nav-mobile-auth-section">
            {user ? (
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <img
                    src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100'}
                    alt={user.name}
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-50"
                    id="nav-mobile-user-avatar"
                  />
                  <div>
                    <h4 className="text-sm font-semibold text-slate-900">{user.name}</h4>
                    <p className="text-xs text-slate-500 truncate max-w-[200px]">{user.headline}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => {
                      setCurrentView('dashboard');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full text-center py-2 text-sm font-medium bg-slate-50 hover:bg-slate-100 rounded-lg text-slate-700 border border-slate-200"
                    id="nav-mobile-dashboard-shortcut"
                  >
                    My Passport
                  </button>
                  <button
                    onClick={() => {
                      onLogout();
                      setMobileMenuOpen(false);
                    }}
                    className="w-full text-center py-2 text-sm font-medium bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg border border-rose-100"
                    id="nav-mobile-logout-shortcut"
                  >
                    Logout
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <button
                  onClick={() => {
                    onOpenAuthModal();
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center justify-center w-full text-center py-2.5 text-base font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-sm"
                  id="nav-mobile-login-btn"
                >
                  <LogIn className="w-5 h-5 mr-2" />
                  Sign In
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
