import React, { useState } from 'react';
import { Award, Briefcase, GraduationCap, Code, ShieldCheck, Plus, Trash2, Settings, Eye, HelpCircle, Upload, CheckCircle, TrendingUp, Sparkles, Sliders } from 'lucide-react';
import { UserProfile, Skill, Certificate, Experience, Project, PrivacySettings } from '../types';

interface DashboardProps {
  user: UserProfile;
  onUpdateUser: (updatedProfile: UserProfile) => void;
}

export default function Dashboard({ user, onUpdateUser }: DashboardProps) {
  // Modal toggle states
  const [showSkillModal, setShowSkillModal] = useState(false);
  const [showCertModal, setShowCertModal] = useState(false);
  
  // New Skill form state
  const [newSkillName, setNewSkillName] = useState('');
  const [newSkillCategory, setNewSkillCategory] = useState<'technical' | 'soft'>('technical');
  const [newSkillLevel, setNewSkillLevel] = useState<'Beginner' | 'Intermediate' | 'Expert'>('Expert');
  const [newSkillYears, setNewSkillYears] = useState(2);

  // New Certificate form state
  const [newCertTitle, setNewCertTitle] = useState('');
  const [newCertIssuer, setNewCertIssuer] = useState('');
  const [newCertDate, setNewCertDate] = useState('');
  const [newCertUrl, setNewCertUrl] = useState('');
  const [selectedSkillForCert, setSelectedSkillForCert] = useState('');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);

  // Edit Bio state
  const [editBio, setEditBio] = useState(user.bio);
  const [editHeadline, setEditHeadline] = useState(user.headline);
  const [editLocation, setEditLocation] = useState(user.location);
  const [isEditingInfo, setIsEditingInfo] = useState(false);

  // Stats calculation
  const totalSkillsCount = user.skills.length;
  const verifiedCertsCount = user.certificates.length;
  const techSkillsCount = user.skills.filter(s => s.category === 'technical').length;
  const softSkillsCount = user.skills.filter(s => s.category === 'soft').length;

  const handlePrivacyToggle = (key: keyof PrivacySettings) => {
    const updatedSettings = {
      ...user.privacySettings,
      [key]: !user.privacySettings[key]
    };
    onUpdateUser({
      ...user,
      privacySettings: updatedSettings
    });
  };

  const handleSaveInfo = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      ...user,
      bio: editBio,
      headline: editHeadline,
      location: editLocation
    });
    setIsEditingInfo(false);
  };

  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSkillName.trim()) return;

    const newSkill: Skill = {
      id: `s-${Date.now()}`,
      name: newSkillName.trim(),
      category: newSkillCategory,
      level: newSkillLevel,
      yearsOfExperience: Number(newSkillYears),
      verified: false
    };

    onUpdateUser({
      ...user,
      skills: [...user.skills, newSkill]
    });

    setNewSkillName('');
    setShowSkillModal(false);
  };

  const handleDeleteSkill = (id: string) => {
    onUpdateUser({
      ...user,
      skills: user.skills.filter(s => s.id !== id)
    });
  };

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setUploadFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setUploadFile(e.target.files[0]);
    }
  };

  const handleAddCertificate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCertTitle.trim() || !newCertIssuer.trim()) return;

    setIsUploading(true);
    
    // Simulate smart contract credential stamping delay
    setTimeout(() => {
      // Generate secure transaction hash representation
      const alphabet = '0123456789abcdef';
      let hash = '0x';
      for (let i = 0; i < 64; i++) {
        hash += alphabet[Math.floor(Math.random() * 16)];
      }

      const newCert: Certificate = {
        id: `cert-${Date.now()}`,
        title: newCertTitle.trim(),
        issuer: newCertIssuer.trim(),
        issueDate: newCertDate || new Date().toISOString().split('T')[0],
        credentialUrl: newCertUrl.trim() || undefined,
        txHash: hash,
        verifiedStatus: 'Verified', // Automatic verification upon credentials uploaded
        skillsRelated: selectedSkillForCert ? [selectedSkillForCert] : []
      };

      // Also trigger verification for associated skill if specified
      const updatedSkills = user.skills.map(sk => {
        if (sk.name === selectedSkillForCert) {
          return { ...sk, verified: true };
        }
        return sk;
      });

      onUpdateUser({
        ...user,
        certificates: [...user.certificates, newCert],
        skills: updatedSkills
      });

      setIsUploading(false);
      setUploadSuccess(true);
      
      setTimeout(() => {
        setUploadSuccess(false);
        setNewCertTitle('');
        setNewCertIssuer('');
        setNewCertDate('');
        setNewCertUrl('');
        setSelectedSkillForCert('');
        setUploadFile(null);
        setShowCertModal(false);
      }, 1500);

    }, 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" id="dashboard-root">
      
      {/* Welcome Banner */}
      <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden mb-10 shadow-lg" id="dashboard-banner">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl -z-10" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6" id="dashboard-banner-inner">
          <div className="space-y-2">
            <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Personal Wallet Secured</span>
            </div>
            <h1 className="text-3xl font-sans font-extrabold tracking-tight">Welcome, {user.name}</h1>
            <p className="text-sm text-slate-300 max-w-xl">
              Track your skill validation process, upload credentials, and configure public access parameters for recruitment teams.
            </p>
          </div>
          <button
            onClick={() => setIsEditingInfo(!isEditingInfo)}
            className="self-start md:self-center px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold rounded-xl transition-all"
            id="dashboard-edit-meta-trigger"
          >
            {isEditingInfo ? 'Close Settings' : 'Edit Bio Metadata'}
          </button>
        </div>
      </div>

      {/* Grid: Stats Overview & Simple Profile editor */}
      {isEditingInfo && (
        <form onSubmit={handleSaveInfo} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm mb-10 space-y-4" id="dashboard-edit-form">
          <h3 className="text-base font-sans font-extrabold text-slate-900">Edit Profile Metadata</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Headline / Role</label>
              <input
                type="text"
                value={editHeadline}
                onChange={(e) => setEditHeadline(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                required
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700">Location</label>
              <input
                type="text"
                value={editLocation}
                onChange={(e) => setEditLocation(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                required
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Bio Statement</label>
            <textarea
              value={editBio}
              onChange={(e) => setEditBio(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
              required
            />
          </div>
          <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsEditingInfo(false)}
              className="px-4 py-2 border border-slate-200 text-sm font-semibold rounded-lg text-slate-600 hover:bg-slate-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg"
            >
              Save Profile Changes
            </button>
          </div>
        </form>
      )}

      {/* Main Grid: Left is analytics + controls, Right is skill list & cert uploads */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8" id="dashboard-main-grid">
        
        {/* LEFT COLUMN: ANALYTICS & PRIVACY */}
        <div className="lg:col-span-4 space-y-6" id="dashboard-analytics-column">
          
          {/* Quick Metrics */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-sm">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 font-mono flex items-center">
              <TrendingUp className="w-4 h-4 text-indigo-600 mr-1.5" />
              Passport Metrics
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/50">
                <span className="text-[10px] text-slate-500 font-mono block">TOTAL SKILLS</span>
                <span className="text-2xl font-bold text-slate-900">{totalSkillsCount}</span>
                <div className="text-[10px] text-slate-400 mt-1">{techSkillsCount} Tech / {softSkillsCount} Soft</div>
              </div>
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/50">
                <span className="text-[10px] text-slate-500 font-mono block">VERIFIED CERTS</span>
                <span className="text-2xl font-bold text-emerald-600">{verifiedCertsCount}</span>
                <div className="text-[10px] text-slate-400 mt-1">Stamping Complete</div>
              </div>
            </div>
          </div>

          {/* Privacy & Sharing Parameters */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-sm" id="dashboard-privacy-controls">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-500 font-mono flex items-center">
              <Sliders className="w-4 h-4 text-indigo-600 mr-1.5" />
              Privacy & Access
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between" id="privacy-item-1">
                <div>
                  <h4 className="text-xs font-bold text-slate-800">Allow Public Link View</h4>
                  <p className="text-[10px] text-slate-500">Anyone with the URL can view your passport</p>
                </div>
                <button
                  onClick={() => handlePrivacyToggle('publicView')}
                  className={`w-10 h-6 flex items-center rounded-full p-1 transition-all ${user.privacySettings.publicView ? 'bg-indigo-600 justify-end' : 'bg-slate-200 justify-start'}`}
                >
                  <span className="bg-white w-4 h-4 rounded-full shadow-sm" />
                </button>
              </div>

              <div className="flex items-center justify-between" id="privacy-item-2">
                <div>
                  <h4 className="text-xs font-bold text-slate-800">Show Personal Email</h4>
                  <p className="text-[10px] text-slate-500">Enable direct contact route on profile card</p>
                </div>
                <button
                  onClick={() => handlePrivacyToggle('showContact')}
                  className={`w-10 h-6 flex items-center rounded-full p-1 transition-all ${user.privacySettings.showContact ? 'bg-indigo-600 justify-end' : 'bg-slate-200 justify-start'}`}
                >
                  <span className="bg-white w-4 h-4 rounded-full shadow-sm" />
                </button>
              </div>

              <div className="flex items-center justify-between" id="privacy-item-3">
                <div>
                  <h4 className="text-xs font-bold text-slate-800">Employer Search Visibility</h4>
                  <p className="text-[10px] text-slate-500">Appear in talent search directories for recruiters</p>
                </div>
                <button
                  onClick={() => handlePrivacyToggle('allowEmployerSearch')}
                  className={`w-10 h-6 flex items-center rounded-full p-1 transition-all ${user.privacySettings.allowEmployerSearch ? 'bg-indigo-600 justify-end' : 'bg-slate-200 justify-start'}`}
                >
                  <span className="bg-white w-4 h-4 rounded-full shadow-sm" />
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: MANAGE SKILLS & CERTIFICATES */}
        <div className="lg:col-span-8 space-y-6" id="dashboard-content-column">
          
          {/* Skills Header Action */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6" id="dashboard-skills-manager">
            <div className="flex justify-between items-center" id="skills-header">
              <div>
                <h2 className="text-lg font-sans font-extrabold text-slate-900">Competency Ledger</h2>
                <p className="text-xs text-slate-500">Edit existing skills or link new certificates to initiate validation.</p>
              </div>
              <button
                onClick={() => setShowSkillModal(true)}
                className="flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-sm"
                id="add-skill-trigger"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Skill
              </button>
            </div>

            {/* Existing Skills List */}
            <div className="divide-y divide-slate-100" id="dashboard-skills-list">
              {user.skills.map((skill) => (
                <div key={skill.id} className="py-4 flex items-center justify-between" id={`skills-item-${skill.id}`}>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm font-bold text-slate-900">{skill.name}</span>
                      <span className={`text-[8px] uppercase font-bold tracking-wider font-mono px-1.5 py-0.2 rounded ${
                        skill.category === 'technical' ? 'bg-indigo-50 text-indigo-700' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {skill.category}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 font-medium mt-1">
                      Level: {skill.level} • {skill.yearsOfExperience} years of experience
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    {skill.verified ? (
                      <span className="flex items-center text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                        <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                        Verified
                      </span>
                    ) : (
                      <button
                        onClick={() => {
                          setSelectedSkillForCert(skill.name);
                          setShowCertModal(true);
                        }}
                        className="text-[10px] font-bold text-indigo-600 hover:bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200 transition-all"
                      >
                        Verify Now
                      </button>
                    )}

                    <button
                      onClick={() => handleDeleteSkill(skill.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                      title="Remove Skill"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Certificate Verification Center */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4" id="dashboard-cert-manager">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-lg font-sans font-extrabold text-slate-900 font-sans">Credential Validation Engine</h2>
                <p className="text-xs text-slate-500 font-sans">Stamp verified diplomas or platform license certificates.</p>
              </div>
              <button
                onClick={() => setShowCertModal(true)}
                className="flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg shadow-sm"
                id="add-cert-trigger"
              >
                <Upload className="w-4 h-4 mr-1.5" />
                Validate Cert
              </button>
            </div>

            {/* List of active stamped certs */}
            <div className="space-y-4" id="stamped-certs-ledger">
              {user.certificates.map((cert) => (
                <div key={cert.id} className="bg-slate-50 p-4 rounded-xl border border-slate-200/60 shadow-sm flex flex-col justify-between" id={`ledger-cert-${cert.id}`}>
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">{cert.title}</h4>
                      <p className="text-xs text-slate-500">Issuer: {cert.issuer} • Stamped Date: {cert.issueDate}</p>
                    </div>
                    <span className="text-[9px] bg-emerald-50 border border-emerald-200 text-emerald-700 font-bold font-mono px-2 py-0.5 rounded-full flex items-center">
                      <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                      Verified
                    </span>
                  </div>

                  <div className="mt-3 bg-white px-2 py-1.5 rounded-lg border border-slate-200/50 flex justify-between items-center text-[9px] font-mono text-slate-500">
                    <span className="truncate max-w-[280px]">Hash: {cert.txHash}</span>
                    <span className="text-emerald-600 font-bold">Immutable Block Secure</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

      {/* SKILL MODAL */}
      {showSkillModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4" id="skill-modal-root">
          <div className="bg-white rounded-2xl max-w-md w-full border border-slate-200 p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-sans font-extrabold text-slate-900">Add New Passport Skill</h3>
            
            <form onSubmit={handleAddSkill} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Skill Name</label>
                <input
                  type="text"
                  placeholder="e.g. AWS EKS, TypeScript, UX Research"
                  value={newSkillName}
                  onChange={(e) => setNewSkillName(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Category</label>
                  <select
                    value={newSkillCategory}
                    onChange={(e) => setNewSkillCategory(e.target.value as 'technical' | 'soft')}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                  >
                    <option value="technical">Technical</option>
                    <option value="soft">Soft Skill</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Competency Level</label>
                  <select
                    value={newSkillLevel}
                    onChange={(e) => setNewSkillLevel(e.target.value as 'Beginner' | 'Intermediate' | 'Expert')}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                  >
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Expert">Expert</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700">Years of Experience: {newSkillYears}</label>
                <input
                  type="range"
                  min="1"
                  max="15"
                  value={newSkillYears}
                  onChange={(e) => setNewSkillYears(Number(e.target.value))}
                  className="w-full accent-indigo-600"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowSkillModal(false)}
                  className="px-4 py-2 border border-slate-200 text-xs font-semibold rounded-lg text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg"
                >
                  Append Competency
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CERTIFICATE MODAL WITH DOCUMENT UPLOAD */}
      {showCertModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-sm flex items-center justify-center p-4" id="cert-modal-root">
          <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 p-6 space-y-4 shadow-2xl">
            <h3 className="text-base font-sans font-extrabold text-slate-900 flex items-center">
              <Award className="w-5 h-5 text-indigo-600 mr-1.5" />
              Cryptographic Credential Stamping
            </h3>

            {isUploading ? (
              <div className="py-12 flex flex-col items-center justify-center space-y-4 text-center">
                <div className="w-12 h-12 rounded-full border-4 border-indigo-100 border-t-indigo-600 animate-spin" />
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Validating Cryptographic Signatures...</h4>
                  <p className="text-xs text-slate-500 max-w-xs mt-1">Stamping credential file onto decentralised verification database. Do not close.</p>
                </div>
              </div>
            ) : uploadSuccess ? (
              <div className="py-12 flex flex-col items-center justify-center space-y-3 text-center">
                <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center border-2 border-emerald-200">
                  <CheckCircle className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-emerald-600">Verification Ledger Confirmed!</h4>
                  <p className="text-xs text-slate-500 max-w-xs mt-1">Transaction block generated and appended to passport ledger.</p>
                </div>
              </div>
            ) : (
              <form onSubmit={handleAddCertificate} className="space-y-4">
                
                {/* Drag and Drop Document Upload section */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Upload Certificate Document (PDF or Image proof)</label>
                  <div
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={handleFileDrop}
                    className="border-2 border-dashed border-slate-300 hover:border-indigo-500 rounded-xl p-6 text-center space-y-2 cursor-pointer transition-all bg-slate-50"
                  >
                    <Upload className="w-8 h-8 text-slate-400 mx-auto" />
                    <div className="text-xs text-slate-600">
                      {uploadFile ? (
                        <span className="font-bold text-indigo-600 truncate block max-w-xs mx-auto">✓ {uploadFile.name}</span>
                      ) : (
                        <span>Drag & drop proof file here or <span className="font-bold text-indigo-600 underline">browse</span></span>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-400">PDF, JPG, PNG up to 10MB. Transformed into secure cryptographic proof.</p>
                    <input
                      type="file"
                      id="file-input"
                      className="hidden"
                      onChange={handleFileSelect}
                      accept=".pdf,.jpg,.jpeg,.png"
                    />
                    <button
                      type="button"
                      onClick={() => document.getElementById('file-input')?.click()}
                      className="text-[10px] font-semibold text-indigo-600 hover:bg-indigo-100 bg-white border border-indigo-100 px-2 py-1 rounded"
                    >
                      Select File
                    </button>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Certificate Title</label>
                  <input
                    type="text"
                    placeholder="e.g. AWS Solutions Architect Professional"
                    value={newCertTitle}
                    onChange={(e) => setNewCertTitle(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Credential Issuer</label>
                    <input
                      type="text"
                      placeholder="e.g. AWS, Coursera, MIT"
                      value={newCertIssuer}
                      onChange={(e) => setNewCertIssuer(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                      required
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Link Skill validation</label>
                    <select
                      value={selectedSkillForCert}
                      onChange={(e) => setSelectedSkillForCert(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                    >
                      <option value="">-- No linked skill --</option>
                      {user.skills.map((sk) => (
                        <option key={sk.id} value={sk.name}>{sk.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Issue Date</label>
                    <input
                      type="date"
                      value={newCertDate}
                      onChange={(e) => setNewCertDate(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Validation Link (Optional URL)</label>
                    <input
                      type="url"
                      placeholder="e.g. verify.coursera.org/123"
                      value={newCertUrl}
                      onChange={(e) => setNewCertUrl(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => {
                      setUploadFile(null);
                      setShowCertModal(false);
                    }}
                    className="px-4 py-2 border border-slate-200 text-xs font-semibold rounded-lg text-slate-600 hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg"
                  >
                    Confirm Cryptographic Stamp
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
