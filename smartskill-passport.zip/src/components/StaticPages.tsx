import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, BookOpen, Send, Mail, MapPin, Phone, ShieldCheck, Zap, Star, User, Users, Check, ArrowRight } from 'lucide-react';
import { FAQ_ITEMS, BLOG_POSTS } from '../data';

interface StaticPagesProps {
  initialSubTab?: 'about' | 'pricing' | 'blog' | 'faq' | 'contact';
}

export default function StaticPages({ initialSubTab = 'about' }: StaticPagesProps) {
  const [activeSubTab, setActiveSubTab] = useState<'about' | 'pricing' | 'blog' | 'faq' | 'contact'>(initialSubTab);
  
  // FAQ accordion state
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);
  const [selectedFaqCat, setSelectedFaqCat] = useState<string>('all');

  // Contact Support state
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactSubject, setContactSubject] = useState('Verification Assistance');
  const [contactMsg, setContactMsg] = useState('');
  const [ticketSuccess, setTicketSuccess] = useState(false);
  const [ticketHash, setTicketHash] = useState('');

  // Blog states
  const [blogFilterCat, setBlogFilterCat] = useState<string>('all');

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactEmail || !contactMsg) return;

    // Generate random mock support ticket number
    const ticketNum = `TK-${Math.floor(100000 + Math.random() * 900000)}`;
    setTicketHash(ticketNum);
    setTicketSuccess(true);

    setTimeout(() => {
      setContactName('');
      setContactEmail('');
      setContactMsg('');
      setTicketSuccess(false);
    }, 5000);
  };

  const toggleFaq = (index: number) => {
    setOpenFaqIndex(openFaqIndex === index ? null : index);
  };

  const subTabs = [
    { id: 'about', label: 'How It Works' },
    { id: 'pricing', label: 'Pricing Plans' },
    { id: 'faq', label: 'Help & FAQ' },
    { id: 'blog', label: 'Blog & Resources' },
    { id: 'contact', label: 'Contact Support' },
  ] as const;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" id="static-pages-root">
      
      {/* Sub navigation bar */}
      <div className="flex border-b border-slate-200 overflow-x-auto scrollbar-none mb-10" id="static-subtabs">
        {subTabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveSubTab(tab.id)}
            className={`py-3 px-4 text-sm font-semibold tracking-wide shrink-0 border-b-2 transition-all -mb-[2px] ${
              activeSubTab === tab.id
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* VIEW: ABOUT US & HOW IT WORKS */}
      {activeSubTab === 'about' && (
        <div className="space-y-16 animate-fade-in" id="about-view">
          
          {/* Header */}
          <div className="text-center space-y-4 max-w-3xl mx-auto" id="about-header">
            <h1 className="text-3xl font-sans font-extrabold tracking-tight text-slate-900 sm:text-4xl">
              Decentralized Skill Ownership
            </h1>
            <p className="text-base text-slate-600 leading-relaxed font-sans font-light">
              We believe professionals should own their career credentials, independent of individual company directories or transient databases.
            </p>
          </div>

          {/* Three pillars visual card layout */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8" id="about-pillars">
            <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm space-y-3">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full">01 / CAPABILITIES</span>
              <h3 className="text-lg font-sans font-bold text-slate-900">Unified Skill Catalog</h3>
              <p className="text-xs text-slate-600 leading-relaxed font-sans">
                Collect and organize all your coding profiles, design systems, languages, and technical badges in one single dashboard.
              </p>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm space-y-3">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full">02 / IMMUTABILITY</span>
              <h3 className="text-lg font-sans font-bold text-slate-900">Tamper-Proof Verification</h3>
              <p className="text-xs text-slate-600 leading-relaxed font-sans">
                Each certificate is backed by a secure cryptographic ledger hash signature, making forgery mathematically impossible.
              </p>
            </div>
            <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm space-y-3">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full">03 / OWNERSHIP</span>
              <h3 className="text-lg font-sans font-bold text-slate-900">Total Privacy Controls</h3>
              <p className="text-xs text-slate-600 leading-relaxed font-sans">
                Selectively disclose specific parts of your passport. Lock direct contact channels, hide stats, or turn off public access at any time.
              </p>
            </div>
          </div>

          {/* For Employers specific marketing block */}
          <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-10 border border-slate-800" id="about-employers-b2b">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7 space-y-4">
                <span className="text-xs font-mono font-bold uppercase tracking-widest text-indigo-400">CORPORATE SOLUTIONS</span>
                <h2 className="text-2xl sm:text-3xl font-sans font-extrabold tracking-tight text-white">
                  Accelerate Recruitment with Verified Talent Directories
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-sans font-light">
                  Manual background screening takes weeks and costs hundreds of dollars per candidate. Smart Skill Passport integrates trusted issuers directly with talent portfolios.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-2 font-medium text-slate-200">
                  <div className="flex items-center"><Check className="w-4 h-4 mr-2 text-indigo-400" /> Pre-verified qualification stacks</div>
                  <div className="flex items-center"><Check className="w-4 h-4 mr-2 text-indigo-400" /> Direct-to-candidate secure pipelines</div>
                  <div className="flex items-center"><Check className="w-4 h-4 mr-2 text-indigo-400" /> Cryptographic ledger authentication</div>
                  <div className="flex items-center"><Check className="w-4 h-4 mr-2 text-indigo-400" /> Zero recruitment intermediary fees</div>
                </div>
              </div>
              <div className="lg:col-span-5 bg-slate-850 p-6 rounded-2xl border border-slate-750 space-y-4">
                <h4 className="text-sm font-bold text-white">Request Partner Access</h4>
                <p className="text-xs text-slate-400 font-sans">Join as an official certificate issuer or get advanced employer search tools.</p>
                <button
                  onClick={() => setActiveSubTab('contact')}
                  className="w-full text-center py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg transition-all"
                >
                  Contact Partnership Team
                </button>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* VIEW: PRICING */}
      {activeSubTab === 'pricing' && (
        <div className="space-y-12 animate-fade-in" id="pricing-view">
          
          {/* Header */}
          <div className="text-center space-y-4 max-w-2xl mx-auto" id="pricing-header">
            <h1 className="text-3xl font-sans font-extrabold tracking-tight text-slate-900">
              Simple, Transparent Pricing
            </h1>
            <p className="text-sm text-slate-600 font-sans">
              Smart Skill Passport is always free for individual professionals. Premium tiers offer deeper corporate talent directories, integration tools, and bulk badge issuance.
            </p>
          </div>

          {/* Pricing Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8" id="pricing-grid">
            
            {/* Free tier */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <div>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-widest font-mono">PROFESSIONAL</span>
                  <h3 className="text-xl font-sans font-bold text-slate-900 mt-1">Individual Free</h3>
                </div>
                <div className="text-3xl font-extrabold text-slate-900">$0 <span className="text-xs font-normal text-slate-500">/ forever</span></div>
                <p className="text-xs text-slate-600 font-sans leading-relaxed">
                  Excellent for designers, software developers, and students wanting to secure and share verified skill profiles.
                </p>
                <div className="border-t border-slate-100 pt-4 space-y-2.5 text-xs text-slate-700">
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> Unlimited Skills Inventory</div>
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> 3 Cryptographic Certificate Stamps</div>
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> Shareable Link & QR Profile</div>
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> Basic Privacy Settings</div>
                </div>
              </div>
              <button className="w-full text-center py-2 border border-indigo-600 text-indigo-600 text-xs font-bold rounded-lg hover:bg-indigo-50 transition-all">
                Get Started Free
              </button>
            </div>

            {/* Recruiter tier */}
            <div className="bg-white p-6 rounded-2xl border-2 border-indigo-600 shadow-md flex flex-col justify-between space-y-6 relative">
              <div className="absolute top-0 right-6 -translate-y-1/2 bg-indigo-600 text-white text-[9px] uppercase tracking-wider font-bold px-2.5 py-1 rounded-full">POPULAR</div>
              <div className="space-y-4">
                <div>
                  <span className="text-xs font-bold text-indigo-600 uppercase tracking-widest font-mono">FOR RECRUITERS</span>
                  <h3 className="text-xl font-sans font-bold text-slate-900 mt-1">Employer Plus</h3>
                </div>
                <div className="text-3xl font-extrabold text-slate-900">$49 <span className="text-xs font-normal text-slate-500">/ month</span></div>
                <p className="text-xs text-slate-600 font-sans leading-relaxed">
                  For active hiring managers and startup recruiters looking to search verified candidates and bypass traditional background screening.
                </p>
                <div className="border-t border-slate-100 pt-4 space-y-2.5 text-xs text-slate-700">
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> Advanced Talent Search Directory</div>
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> Filter by badge and level stacks</div>
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> Direct verification ledger inspector</div>
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> 10 Direct Outreach messages / mo</div>
                </div>
              </div>
              <button className="w-full text-center py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg transition-all shadow-sm">
                Start Recruiter Trial
              </button>
            </div>

            {/* Issuer tier */}
            <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <div>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-widest font-mono">ORGANIZATIONS</span>
                  <h3 className="text-xl font-sans font-bold text-slate-900 mt-1">Platform Issuer</h3>
                </div>
                <div className="text-3xl font-extrabold text-slate-900">$199 <span className="text-xs font-normal text-slate-500">/ month</span></div>
                <p className="text-xs text-slate-600 font-sans leading-relaxed">
                  For bootcamps, universities, and certificate program issuers who want to generate blockchain verified credentials automatically for students.
                </p>
                <div className="border-t border-slate-100 pt-4 space-y-2.5 text-xs text-slate-700">
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> Automated badge issuance API</div>
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> Custom branding on generated certificates</div>
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> Analytics for graduate directories</div>
                  <div className="flex items-center"><Check className="w-4 h-4 text-emerald-500 mr-2 shrink-0" /> Priority developer support</div>
                </div>
              </div>
              <button
                onClick={() => setActiveSubTab('contact')}
                className="w-full text-center py-2 border border-slate-300 text-slate-700 text-xs font-bold rounded-lg hover:bg-slate-50 transition-all"
              >
                Inquire Partnership
              </button>
            </div>

          </div>
        </div>
      )}

      {/* VIEW: HELP & FAQ */}
      {activeSubTab === 'faq' && (
        <div className="space-y-10 animate-fade-in" id="faq-view">
          
          {/* Header */}
          <div className="text-center space-y-4 max-w-2xl mx-auto" id="faq-header">
            <h1 className="text-3xl font-sans font-extrabold tracking-tight text-slate-900">
              Frequently Answered Questions
            </h1>
            <p className="text-sm text-slate-600 font-sans">
              Find technical answers about the verification ledgers, profile privacy, and employer search mechanisms.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex justify-center space-x-2" id="faq-filter-pillbox">
            {['all', 'General', 'Verification', 'Privacy', 'For Employers'].map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedFaqCat(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                  selectedFaqCat === cat
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {cat === 'all' ? 'All Questions' : cat}
              </button>
            ))}
          </div>

          {/* Accordion Questions list */}
          <div className="max-w-3xl mx-auto divide-y divide-slate-200 border-t border-b border-slate-200" id="faq-accordion">
            {FAQ_ITEMS.filter(faq => selectedFaqCat === 'all' || faq.category === selectedFaqCat).map((faq, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div key={index} className="py-4" id={`faq-item-${index}`}>
                  <button
                    onClick={() => toggleFaq(index)}
                    className="w-full flex items-center justify-between text-left focus:outline-none"
                  >
                    <span className="text-sm sm:text-base font-bold text-slate-900">{faq.question}</span>
                    {isOpen ? <ChevronUp className="w-5 h-5 text-indigo-600" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
                  </button>
                  {isOpen && (
                    <div className="mt-2 text-xs sm:text-sm text-slate-600 leading-relaxed font-sans font-light">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </div>
      )}

      {/* VIEW: BLOG */}
      {activeSubTab === 'blog' && (
        <div className="space-y-12 animate-fade-in" id="blog-view">
          
          {/* Header */}
          <div className="text-center space-y-4 max-w-2xl mx-auto" id="blog-header">
            <h1 className="text-3xl font-sans font-extrabold tracking-tight text-slate-900">
              Blog & Industry Resources
            </h1>
            <p className="text-sm text-slate-600 font-sans">
              Learn about decentralized IDs (DIDs), digital identity compliance, and standard on-chain certification schemas.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex justify-center space-x-2" id="blog-filter-pillbox">
            {['all', 'Technology', 'Career Advice', 'Industry Trends'].map((cat) => (
              <button
                key={cat}
                onClick={() => setBlogFilterCat(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                  blogFilterCat === cat
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-sm'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {cat === 'all' ? 'All Posts' : cat}
              </button>
            ))}
          </div>

          {/* Blog posts list */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8" id="blog-posts-grid">
            {BLOG_POSTS.filter(post => blogFilterCat === 'all' || post.category === blogFilterCat).map((post) => (
              <article
                key={post.id}
                className="bg-white rounded-2xl border border-slate-200/60 p-5 shadow-sm hover:shadow-md hover:border-slate-300 transition-all flex flex-col justify-between space-y-4"
                id={`blog-post-${post.id}`}
              >
                <div className="space-y-3">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600 font-mono">{post.category}</span>
                  <h3 className="text-base font-bold text-slate-900 hover:text-indigo-600 cursor-pointer transition-colors leading-snug">
                    {post.title}
                  </h3>
                  <p className="text-xs text-slate-500 font-light font-sans leading-relaxed line-clamp-3">
                    {post.excerpt}
                  </p>
                </div>

                <div className="flex justify-between items-center text-[10px] text-slate-400 font-mono pt-3 border-t border-slate-100">
                  <span>By {post.author}</span>
                  <span>{post.readTime}</span>
                </div>
              </article>
            ))}
          </div>

        </div>
      )}

      {/* VIEW: CONTACT SUPPORT */}
      {activeSubTab === 'contact' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start animate-fade-in" id="contact-view">
          
          {/* Left contact info cards */}
          <div className="lg:col-span-5 space-y-6" id="contact-left-details">
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 font-mono">Contact & Support</span>
              <h1 className="text-3xl font-sans font-extrabold tracking-tight text-slate-900">
                Get In Touch
              </h1>
              <p className="text-sm text-slate-600 font-sans">
                Having issues validating a credential? Need to set up a custom institutional issuer signature? Send a support ticket directly to our engineers.
              </p>
            </div>

            <div className="space-y-4" id="contact-info-cards">
              <div className="flex items-center space-x-3 bg-white p-4 rounded-xl border border-slate-200/50 shadow-sm">
                <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Email Assistance</h4>
                  <p className="text-[11px] text-slate-500 font-mono">support@smartskillpassport.io</p>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white p-4 rounded-xl border border-slate-200/50 shadow-sm">
                <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Decentralized HQ</h4>
                  <p className="text-[11px] text-slate-500 font-sans">64 Ledger Blvd, San Francisco, CA</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right contact support form */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm" id="contact-form-card">
            
            {ticketSuccess ? (
              <div className="py-12 text-center space-y-4" id="support-success-block">
                <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-100 flex items-center justify-center mx-auto">
                  <ShieldCheck className="w-6 h-6 animate-bounce" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-bold text-slate-900">Support Request Stamped!</h3>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    We have successfully queued your assistance ticket. An agent will contact you shortly.
                  </p>
                  <p className="text-[10px] font-mono text-indigo-600 pt-2 font-bold bg-indigo-50/50 inline-block px-3 py-1 rounded">
                    Ticket ID: {ticketHash}
                  </p>
                </div>
              </div>
            ) : (
              <form onSubmit={handleContactSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Your Full Name</label>
                    <input
                      type="text"
                      placeholder="Elena Rostova"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                      required
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-slate-700">Direct Email Address</label>
                    <input
                      type="email"
                      placeholder="elena.r@cloudops.io"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Subject / Category</label>
                  <select
                    value={contactSubject}
                    onChange={(e) => setContactSubject(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                  >
                    <option value="Verification Assistance">Verification Assistance</option>
                    <option value="Partner Issuer Onboarding">Partner Issuer Onboarding</option>
                    <option value="Employer Account Inquiry">Employer Account Inquiry</option>
                    <option value="General Question">General Question</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700">Detailed Message</label>
                  <textarea
                    rows={4}
                    placeholder="Describe your issue or integration goals clearly..."
                    value={contactMsg}
                    onChange={(e) => setContactMsg(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-lg shadow-sm flex items-center justify-center space-x-2 transition-all"
                  id="contact-form-submit-btn"
                >
                  <Send className="w-4 h-4" />
                  <span>Transmit Support Ticket</span>
                </button>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
