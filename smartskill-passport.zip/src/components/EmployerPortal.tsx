import React, { useState } from 'react';
import { Search, MapPin, ShieldCheck, Award, Eye, Filter, CheckCircle2, UserCheck, CheckCircle } from 'lucide-react';
import { UserProfile, Skill } from '../types';

interface EmployerPortalProps {
  allUsers: UserProfile[];
  onViewPassport: (user: UserProfile) => void;
}

export default function EmployerPortal({
  allUsers,
  onViewPassport
}: EmployerPortalProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [onlyVerified, setOnlyVerified] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Filter users who allow employer search
  const discoverableUsers = allUsers.filter(u => u.privacySettings.allowEmployerSearch);

  // Filter logic
  const filteredUsers = discoverableUsers.filter(user => {
    // Search by name, headline, or skill names
    const matchesQuery = searchQuery.trim() === '' || 
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.headline.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.skills.some(s => s.name.toLowerCase().includes(searchQuery.toLowerCase()));

    // Filter by skill level inside their matches
    const matchesLevel = selectedLevel === 'all' ||
      user.skills.some(s => s.level.toLowerCase() === selectedLevel.toLowerCase());

    // Filter by category
    const matchesCategory = selectedCategory === 'all' ||
      user.skills.some(s => s.category.toLowerCase() === selectedCategory.toLowerCase());

    // Filter by verified credentials
    const matchesVerified = !onlyVerified ||
      user.skills.some(s => s.verified);

    return matchesQuery && matchesLevel && matchesCategory && matchesVerified;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" id="employer-portal-root">
      
      {/* Intro Banner */}
      <div className="space-y-4 max-w-3xl mb-10" id="employer-intro">
        <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 font-mono">Employer Talents Board</span>
        <h1 className="text-3xl font-sans font-extrabold tracking-tight text-slate-900 sm:text-4xl">
          Instantly Search Verified Capability Passports
        </h1>
        <p className="text-base text-slate-600">
          Search candidate portfolios with absolute guarantee of qualification validity. Direct integration into decentralized credential ledgers eliminates credentials verification delays.
        </p>
      </div>

      {/* Control filters bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4 mb-8" id="employer-filter-bar">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          
          {/* Search field */}
          <div className="md:col-span-5 relative" id="search-input-wrapper">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by skill (e.g. AWS, Next.js, PyTorch) or candidate name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 border border-slate-300 rounded-xl text-sm bg-white"
            />
          </div>

          {/* Skill Level filter */}
          <div className="md:col-span-3" id="level-select-wrapper">
            <select
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-xl text-sm bg-white text-slate-700"
            >
              <option value="all">Any Competency Level</option>
              <option value="expert">Expert</option>
              <option value="intermediate">Intermediate</option>
              <option value="beginner">Beginner</option>
            </select>
          </div>

          {/* Category filter */}
          <div className="md:col-span-2" id="category-select-wrapper">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3 py-2.5 border border-slate-300 rounded-xl text-sm bg-white text-slate-700"
            >
              <option value="all">Any Category</option>
              <option value="technical">Technical</option>
              <option value="soft">Soft Skill</option>
            </select>
          </div>

          {/* Verified toggle checkbox */}
          <div className="md:col-span-2 flex items-center justify-start md:justify-end" id="verified-checkbox-wrapper">
            <label className="inline-flex items-center space-x-2 cursor-pointer text-xs font-semibold text-slate-700 select-none">
              <input
                type="checkbox"
                checked={onlyVerified}
                onChange={() => setOnlyVerified(!onlyVerified)}
                className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4.5 h-4.5"
              />
              <span>Only Verified Badges</span>
            </label>
          </div>

        </div>
      </div>

      {/* Directory Results */}
      <div className="space-y-4" id="employer-results-list">
        <div className="flex justify-between items-center text-xs text-slate-500 font-semibold" id="employer-results-info">
          <span>Displaying {filteredUsers.length} discoverable capabilities profiles</span>
        </div>

        {filteredUsers.length === 0 ? (
          <div className="py-16 text-center bg-white rounded-2xl border border-slate-200 text-slate-500" id="empty-search-state">
            No matching capabilities passports were found with your specified filters. Try expanding your search queries.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="candidates-grid">
            {filteredUsers.map((user) => {
              const totalSkillsCount = user.skills.length;
              const verifiedSkillsCount = user.skills.filter(s => s.verified).length;

              return (
                <div
                  key={user.id}
                  className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md hover:border-slate-300 transition-all flex flex-col justify-between"
                  id={`candidate-card-${user.id}`}
                >
                  <div className="space-y-4">
                    {/* User Meta Row */}
                    <div className="flex items-start space-x-4">
                      <img
                        src={user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100'}
                        alt={user.name}
                        referrerPolicy="no-referrer"
                        className="w-12 h-12 rounded-xl object-cover ring-2 ring-indigo-50"
                      />
                      <div className="space-y-1">
                        <h3 className="text-base font-bold text-slate-900 flex items-center">
                          {user.name}
                          {verifiedSkillsCount > 0 && (
                            <span className="ml-1.5 p-0.5 rounded bg-emerald-50 text-emerald-600 border border-emerald-100" title="Has Blockchain Stamped Badges">
                              <ShieldCheck className="w-4 h-4" />
                            </span>
                          )}
                        </h3>
                        <p className="text-xs text-indigo-600 font-semibold">{user.headline}</p>
                        <p className="text-[10px] text-slate-500 font-medium flex items-center">
                          <MapPin className="w-3 h-3 mr-1" />
                          {user.location}
                        </p>
                      </div>
                    </div>

                    {/* Bio Snippet */}
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                      {user.bio}
                    </p>

                    {/* Key Skills Pill Matrix */}
                    <div className="space-y-1.5">
                      <span className="text-[9px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Key Verified Badges ({verifiedSkillsCount}/{totalSkillsCount})</span>
                      <div className="flex flex-wrap gap-1">
                        {user.skills.slice(0, 5).map((sk) => (
                          <span
                            key={sk.id}
                            className={`text-[9px] font-mono px-2 py-0.5 rounded flex items-center border ${
                              sk.verified
                                ? 'bg-emerald-50 text-emerald-800 border-emerald-200 font-bold'
                                : 'bg-slate-50 text-slate-700 border-slate-200'
                            }`}
                          >
                            {sk.verified && <CheckCircle className="w-3 h-3 text-emerald-600 mr-1 shrink-0" />}
                            {sk.name} ({sk.level})
                          </span>
                        ))}
                        {user.skills.length > 5 && (
                          <span className="text-[9px] font-mono text-slate-400 bg-slate-50 border border-slate-200 px-2 py-0.5 rounded font-bold">+{user.skills.length - 5} more</span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Primary CTA */}
                  <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-400">Verifications verified via Ledger</span>
                    <button
                      onClick={() => onViewPassport(user)}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-lg flex items-center space-x-1 shadow-sm"
                      id={`candidate-view-btn-${user.id}`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Examine Passport</span>
                    </button>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
