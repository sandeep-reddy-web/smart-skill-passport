import React, { useState } from 'react';
import { Award, ShieldCheck, ShieldAlert, CheckCircle2, Search, Calendar, Cpu, User, ExternalLink, ArrowRight } from 'lucide-react';
import { UserProfile, Certificate } from '../types';

interface VerificationCenterProps {
  allUsers: UserProfile[];
}

export default function VerificationCenter({ allUsers }: VerificationCenterProps) {
  const [lookupHash, setLookupHash] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [foundMatch, setFoundMatch] = useState<{ user: UserProfile; cert: Certificate } | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  // Auto-fill template hashes for testing convenience
  const demoHashes = [
    { name: "Elena's AWS SA-Pro", hash: "0x8f3c7d9a1e0b5c4f2a7d8e9c0b1a2e3f4c5b6a7d8e9f0a1b2c3d4e5f6a7b8c9d" },
    { name: "Liam's Google UX", hash: "0xda3f4c5b6a7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2a3c4b5d6e7f8a9b0c1d2e3f" },
    { name: "Sarah's Deep Learning", hash: "0x1c2b3a4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b" },
  ];

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lookupHash.trim()) return;

    setIsVerifying(true);
    setHasSearched(false);
    setFoundMatch(null);

    // Simulate cryptographic ledger search delay
    setTimeout(() => {
      let matchedData: { user: UserProfile; cert: Certificate } | null = null;

      // Scan all users to locate corresponding ledger certificate
      for (const u of allUsers) {
        const foundCert = u.certificates.find(c => c.txHash.toLowerCase() === lookupHash.trim().toLowerCase());
        if (foundCert) {
          matchedData = { user: u, cert: foundCert };
          break;
        }
      }

      setFoundMatch(matchedData);
      setIsVerifying(false);
      setHasSearched(true);
    }, 1500);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10" id="verification-center-root">
      
      {/* Intro Header */}
      <div className="text-center space-y-4 max-w-2xl mx-auto mb-10" id="verify-intro">
        <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-700 text-xs font-semibold">
          <ShieldCheck className="w-4 h-4" />
          <span>Immutable Ledger Validator</span>
        </div>
        <h1 className="text-3xl font-sans font-extrabold tracking-tight text-slate-900 sm:text-4xl">
          Certificate Validation Center
        </h1>
        <p className="text-sm text-slate-600 font-sans">
          Paste a Smart Skill Passport cryptographic transaction hash to verify the absolute authenticity of any competency certificate.
        </p>
      </div>

      {/* Lookup Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-4" id="verify-form-panel">
        <form onSubmit={handleVerify} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700">Paste Verification Hash (64-character hex signature)</label>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                placeholder="e.g. 0x8f3c7d9a1e0b5c4f2a7d8e9c0b1a2e3f4c5b6a7d8e9f..."
                value={lookupHash}
                onChange={(e) => setLookupHash(e.target.value)}
                className="flex-1 px-3 py-2.5 border border-slate-300 rounded-xl text-xs font-mono bg-white text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
              <button
                type="submit"
                disabled={isVerifying}
                className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white text-xs font-semibold rounded-xl shadow-sm transition-all flex items-center justify-center shrink-0"
                id="ledger-submit-btn"
              >
                {isVerifying ? 'Searching Ledger...' : 'Verify Ledger Record'}
              </button>
            </div>
          </div>
        </form>

        {/* Demo Quickfill Links */}
        <div className="pt-2 border-t border-slate-100 space-y-2" id="verify-demo-pillbox">
          <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">Quickfill Demo Signatures</span>
          <div className="flex flex-col sm:flex-row gap-2">
            {demoHashes.map((demo, index) => (
              <button
                key={index}
                onClick={() => setLookupHash(demo.hash)}
                className="text-[10px] bg-slate-50 hover:bg-slate-100 text-slate-600 px-3 py-1.5 rounded-lg border border-slate-200 text-left truncate font-mono flex items-center justify-between"
                title={demo.hash}
              >
                <span className="font-semibold truncate mr-2">{demo.name}</span>
                <span className="text-indigo-600 shrink-0">Click to load</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Verification Results Display */}
      <div className="mt-8" id="verification-results-container">
        {isVerifying && (
          <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-4" id="verifying-status">
            <div className="w-12 h-12 rounded-full border-4 border-indigo-100 border-t-indigo-600 animate-spin mx-auto" />
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-slate-800">Interrogating Decentralized Ledger Index...</h3>
              <p className="text-xs text-slate-500">Querying cryptographic signature block against registered issuers.</p>
            </div>
          </div>
        )}

        {hasSearched && !isVerifying && (
          foundMatch ? (
            <div className="bg-white rounded-2xl border border-emerald-200 p-6 sm:p-8 shadow-sm space-y-6 relative overflow-hidden" id="match-found-panel">
              {/* Decorative side accent */}
              <div className="absolute left-0 top-0 bottom-0 w-2 bg-emerald-500" />
              
              {/* Certificate Verification Header badge */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-6 h-6 text-emerald-500" />
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 font-mono">Ledger Authenticity Confirmed</span>
                </div>
                <span className="text-[10px] font-mono text-slate-400">Block Verified (UTC Timestamped)</span>
              </div>

              {/* Verified Details Sheet */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="cert-verify-sheet">
                
                {/* Left: Cert metadata */}
                <div className="space-y-4">
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">CERTIFICATION TITLE</span>
                    <h2 className="text-lg font-sans font-extrabold text-slate-900">{foundMatch.cert.title}</h2>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">ISSUER AUTHORITY</span>
                      <p className="text-xs text-slate-700 font-semibold flex items-center">
                        <Cpu className="w-3.5 h-3.5 mr-1 text-indigo-500" />
                        {foundMatch.cert.issuer}
                      </p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">TIMESTAMPED DATE</span>
                      <p className="text-xs text-slate-700 font-semibold flex items-center">
                        <Calendar className="w-3.5 h-3.5 mr-1 text-indigo-500" />
                        {foundMatch.cert.issueDate}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">SIGNATURE LEDGER HASH</span>
                    <p className="text-[10px] font-mono bg-slate-50 p-2 border border-slate-200 text-slate-600 select-all rounded truncate">
                      {foundMatch.cert.txHash}
                    </p>
                  </div>
                </div>

                {/* Right: Recipient owner metadata */}
                <div className="bg-slate-50 p-5 rounded-xl border border-slate-200/50 space-y-4" id="recipient-meta-box">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400 block font-bold">RECIPIENT INFORMATION</span>
                  <div className="flex items-center space-x-3">
                    <img
                      src={foundMatch.user.avatarUrl || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=100'}
                      alt={foundMatch.user.name}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-lg object-cover ring-2 ring-emerald-500/20"
                    />
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">{foundMatch.user.name}</h4>
                      <p className="text-xs text-indigo-600 font-semibold">{foundMatch.user.headline}</p>
                    </div>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed font-sans border-t border-slate-200/60 pt-3">
                    This user holds a cryptographically authentic capability passport. The credential shown has been signed and validated by the issuer authority, with the record locked onto the network ledger permanently.
                  </p>
                </div>

              </div>

            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-rose-200 p-8 text-center space-y-4 relative overflow-hidden" id="match-failed-panel">
              <div className="absolute left-0 top-0 bottom-0 w-2 bg-rose-500" />
              <div className="w-10 h-10 bg-rose-50 text-rose-600 border border-rose-100 rounded-full flex items-center justify-center mx-auto">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-rose-700">Verification Ledger Look-up Failed</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                  We could not locate any active signature blocks corresponding to this hash in the current global index. Make sure you entered the correct 64-character hash value.
                </p>
              </div>
            </div>
          )
        )}
      </div>

    </div>
  );
}
