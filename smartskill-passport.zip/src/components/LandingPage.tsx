import React from 'react';
import { Shield, Sparkles, Share2, Award, ArrowRight, UserCheck, Eye, Compass, Code, Database, Brain } from 'lucide-react';

interface LandingPageProps {
  onStartOnboarding: () => void;
  onExploreFeatures: () => void;
  onEmployerSearch: () => void;
  onViewDemo: () => void;
}

export default function LandingPage({
  onStartOnboarding,
  onExploreFeatures,
  onEmployerSearch,
  onViewDemo
}: LandingPageProps) {
  // Mock live verifications feed
  const liveVerifications = [
    { name: "AWS SA-Pro", hash: "0x8f3c...6a7b", time: "1m ago", status: "Verified" },
    { name: "Google Cloud Architect", hash: "0x3e1a...2f5d", time: "3m ago", status: "Verified" },
    { name: "Meta Frontend Cert", hash: "0xfa9b...4e1c", time: "5m ago", status: "Verified" },
  ];

  return (
    <div className="bg-slate-50 min-h-screen" id="landing-page-root">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 sm:py-28 bg-white border-b border-slate-100" id="hero-section">
        <div className="absolute inset-0 bg-[radial-gradient(45rem_50rem_at_top,theme(colors.indigo.50),white)] opacity-70" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[350px] bg-indigo-200/10 rounded-full blur-3xl -z-10" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center" id="hero-grid">
            
            {/* Hero Left */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left" id="hero-content">
              <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-700 text-xs font-semibold" id="hero-badge">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Next-Gen Decentralized Credentials</span>
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-sans font-extrabold tracking-tight text-slate-900 leading-tight" id="hero-heading">
                Your Skills. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-violet-600">Verified & Portable.</span>
              </h1>
              
              <p className="text-lg text-slate-600 max-w-xl mx-auto lg:mx-0 font-sans font-light leading-relaxed" id="hero-description">
                Establish an immutable, self-sovereign digital resume. Smart Skill Passport gathers your skills, experiences, and educational credentials into a single cryptographically-stamped link that recruiters can trust immediately.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2" id="hero-actions">
                <button
                  onClick={onStartOnboarding}
                  className="w-full sm:w-auto px-8 py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl shadow-lg shadow-indigo-100 hover:shadow-indigo-200 transition-all duration-200 flex items-center justify-center group"
                  id="hero-cta-signup"
                >
                  Create Your Passport
                  <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </button>
                <button
                  onClick={onViewDemo}
                  className="w-full sm:w-auto px-8 py-3.5 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-semibold rounded-xl shadow-sm transition-all duration-200 flex items-center justify-center"
                  id="hero-cta-demo"
                >
                  Explore Demo Account
                </button>
              </div>

              {/* Quick Trust Highlights */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-slate-100" id="hero-trust-indicators">
                <div id="trust-indicator-1">
                  <h4 className="text-2xl font-bold text-slate-900">100%</h4>
                  <p className="text-xs text-slate-500 font-medium">Tamper-Proof Proofs</p>
                </div>
                <div id="trust-indicator-2">
                  <h4 className="text-2xl font-bold text-slate-900">Instant</h4>
                  <p className="text-xs text-slate-500 font-medium">QR Code Sharing</p>
                </div>
                <div id="trust-indicator-3">
                  <h4 className="text-2xl font-bold text-slate-900">Zero</h4>
                  <p className="text-xs text-slate-500 font-medium">Recruitment Fraud</p>
                </div>
              </div>
            </div>

            {/* Hero Right - Interactive Passport Mockup */}
            <div className="lg:col-span-5 flex justify-center lg:justify-end" id="hero-mockup-wrapper">
              <div className="w-full max-w-sm bg-slate-900 text-white rounded-3xl shadow-2xl border-4 border-slate-800 p-6 relative overflow-hidden" id="hero-passport-mock">
                {/* Visual Glow */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/20 rounded-full blur-2xl" />
                <div className="absolute -bottom-8 -left-8 w-40 h-40 bg-violet-500/20 rounded-full blur-2xl" />

                {/* Passport Header */}
                <div className="flex justify-between items-start mb-6" id="passport-mock-header">
                  <div>
                    <span className="text-[10px] uppercase font-mono tracking-widest text-indigo-400">Official Web3 Digital Identity</span>
                    <h3 className="text-lg font-sans font-bold tracking-tight text-white mt-1">SKILL PASSPORT</h3>
                  </div>
                  <Shield className="w-8 h-8 text-indigo-400 shrink-0" />
                </div>

                {/* Passport Body */}
                <div className="space-y-4 relative z-10" id="passport-mock-body">
                  <div className="flex items-center space-x-3" id="passport-mock-user-meta">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 p-0.5 shadow-md">
                      <img
                        src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100"
                        alt="Liam Chen Profile Mock"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover rounded-[10px]"
                      />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Liam Chen</h4>
                      <p className="text-[10px] text-slate-400 font-mono">ID: SSP-7102-CHEN</p>
                    </div>
                  </div>

                  {/* Skills tags */}
                  <div className="space-y-1.5" id="passport-mock-skills-summary">
                    <span className="text-[10px] font-mono text-slate-400">VERIFIED SKILLS</span>
                    <div className="flex flex-wrap gap-1">
                      <span className="text-[9px] bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded font-mono">✓ React & Next.js</span>
                      <span className="text-[9px] bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded font-mono">✓ Tailwind CSS</span>
                      <span className="text-[9px] bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded font-mono">✓ UX Prototyping</span>
                    </div>
                  </div>

                  {/* Verifications logs */}
                  <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/50 space-y-2" id="passport-mock-tx-logs">
                    <span className="text-[9px] font-mono text-slate-400 block uppercase">Blockchain Stamped Certificates</span>
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-[10px]">
                        <span className="text-slate-200 font-medium">Google UX Design</span>
                        <span className="text-emerald-400 font-mono">0xda3f...2e3f</span>
                      </div>
                      <div className="flex justify-between text-[10px]">
                        <span className="text-slate-200 font-medium">Meta Front-End Capstone</span>
                        <span className="text-emerald-400 font-mono">0x9a8b...a8b</span>
                      </div>
                    </div>
                  </div>

                  {/* Interactive Buttons */}
                  <div className="grid grid-cols-2 gap-2 pt-2" id="passport-mock-actions">
                    <button
                      onClick={onEmployerSearch}
                      className="w-full text-center py-2 text-[10px] font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 transition-all flex items-center justify-center space-x-1"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Employer Directory</span>
                    </button>
                    <button
                      onClick={onExploreFeatures}
                      className="w-full text-center py-2 text-[10px] font-semibold bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-all flex items-center justify-center space-x-1"
                    >
                      <Compass className="w-3.5 h-3.5" />
                      <span>Learn Features</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Live Blockchain Verifications Ticker */}
      <div className="bg-slate-900 text-white py-3 border-y border-slate-800 overflow-hidden" id="verification-ticker">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-2 md:gap-0">
          <div className="flex items-center space-x-2 shrink-0">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-xs font-semibold tracking-wider uppercase text-slate-400 font-mono">Live Cryptographic Cert Ledger:</span>
          </div>
          <div className="flex items-center space-x-6 overflow-x-auto text-xs font-mono scrollbar-none" id="ticker-items">
            {liveVerifications.map((item, index) => (
              <div key={index} className="flex items-center space-x-2 shrink-0">
                <span className="text-slate-300 font-medium">{item.name}</span>
                <span className="text-indigo-400 bg-indigo-950/50 border border-indigo-900/30 px-1.5 py-0.2 rounded text-[10px]">{item.hash}</span>
                <span className="text-slate-500 text-[10px]">{item.time}</span>
                <span className="text-emerald-400 text-[10px] font-bold bg-emerald-950/20 border border-emerald-900/30 px-1 rounded">✓ {item.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Key Features Spotlight Section */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="features-grid-section">
        <div className="text-center space-y-4 max-w-3xl mx-auto mb-16" id="features-section-header">
          <h2 className="text-3xl font-sans font-extrabold tracking-tight text-slate-900 sm:text-4xl">
            A Better Way to Own & Share Credentials
          </h2>
          <p className="text-lg text-slate-600 leading-relaxed font-sans font-light">
            Traditional CVs are easily fabricated, hard to verify, and locked inside siloed systems. Smart Skill Passport is built on modern decentralized identity frameworks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8" id="features-cards">
          {/* Card 1 */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm hover:shadow-md transition-all duration-200 space-y-4 group" id="feat-card-1">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300 shadow-inner">
              <Shield className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-sans font-bold text-slate-900">Decentralized Security</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Every badge and license has a unique transaction verification ID that references an immutable proof, keeping credentials safe from fraud.
            </p>
          </div>

          {/* Card 2 */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm hover:shadow-md transition-all duration-200 space-y-4 group" id="feat-card-2">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300 shadow-inner">
              <Share2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-sans font-bold text-slate-900">Instant Portability</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Share your entire verified skills catalog anywhere. Export as a lightweight verifiable link, a printable QR passport, or integrated into social feeds.
            </p>
          </div>

          {/* Card 3 */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm hover:shadow-md transition-all duration-200 space-y-4 group" id="feat-card-3">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300 shadow-inner">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-sans font-bold text-slate-900">Verifiable Badges</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Never get questioned about your proficiencies again. Your certificates are linked back to trusted issuers with cryptographically stamped timestamps.
            </p>
          </div>

          {/* Card 4 */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200/60 shadow-sm hover:shadow-md transition-all duration-200 space-y-4 group" id="feat-card-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-all duration-300 shadow-inner">
              <UserCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-sans font-bold text-slate-900">Employer Verified</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Hiring managers can search for candidates with fully certified qualifications, bypassing lengthy manual background checking cycles completely.
            </p>
          </div>
        </div>
      </section>

      {/* Structured "How it Works" Visual Grid */}
      <section className="bg-white py-20 border-t border-b border-slate-100" id="how-it-works-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left side text */}
            <div className="lg:col-span-5 space-y-6" id="how-it-works-left">
              <span className="text-xs font-bold uppercase tracking-wider text-indigo-600">Simple 3-Step Lifecycle</span>
              <h2 className="text-3xl sm:text-4xl font-sans font-extrabold tracking-tight text-slate-900">
                Setup and Share Your Digital Passport
              </h2>
              <p className="text-base text-slate-600 leading-relaxed">
                Smart Skill Passport automates the tedious verification processes of resume screening, aligning certifications directly with visual skill scores.
              </p>
              
              <div className="space-y-4" id="how-it-works-bullets">
                <div className="flex items-start space-x-3" id="how-bullet-1">
                  <div className="flex items-center justify-center w-6 h-6 rounded-full bg-indigo-50 text-indigo-600 text-xs font-bold shrink-0 mt-0.5">1</div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Onboard and Add Competencies</h4>
                    <p className="text-xs text-slate-500">Sign up and build your technical, soft skill, project, and work experience inventory.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3" id="how-bullet-2">
                  <div className="flex items-center justify-center w-6 h-6 rounded-full bg-indigo-50 text-indigo-600 text-xs font-bold shrink-0 mt-0.5">2</div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Validate with Official Credentials</h4>
                    <p className="text-xs text-slate-500">Upload or link certificate credentials. Each document receives a verification hash.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3" id="how-bullet-3">
                  <div className="flex items-center justify-center w-6 h-6 rounded-full bg-indigo-50 text-indigo-600 text-xs font-bold shrink-0 mt-0.5">3</div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Share Publicly or Opt-In Employer Search</h4>
                    <p className="text-xs text-slate-500">Generate a secure shareable passport link or choose to let premium employers discover your verified credentials.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right side illustrations representing dynamic pages */}
            <div className="lg:col-span-7" id="how-it-works-right">
              <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-6 sm:p-8 space-y-6" id="how-mock-panel">
                <div className="flex items-center justify-between border-b border-slate-200/60 pb-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-3.5 h-3.5 rounded-full bg-slate-300" />
                    <div className="w-3.5 h-3.5 rounded-full bg-slate-300" />
                    <div className="w-3.5 h-3.5 rounded-full bg-slate-300" />
                  </div>
                  <span className="text-[10px] text-slate-400 font-mono">https://passport.smartskill.io/elena-rostova</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Mock profile widget */}
                  <div className="bg-white p-4 rounded-xl border border-slate-200/60 shadow-sm space-y-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600">
                        <Code className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="text-xs font-bold text-slate-800">Elena Rostova</h4>
                        <p className="text-[9px] text-slate-400">DevOps Expert</p>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px]">
                        <span className="text-slate-500">Cloud Strategy</span>
                        <span className="text-emerald-600 font-bold">Expert ✓</span>
                      </div>
                      <div className="w-full bg-slate-100 h-1 rounded-full overflow-hidden">
                        <div className="bg-emerald-500 h-full w-11/12" />
                      </div>
                    </div>
                  </div>

                  {/* Mock certificate verification widget */}
                  <div className="bg-white p-4 rounded-xl border border-slate-200/60 shadow-sm space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-mono text-indigo-600 uppercase font-bold">AWS Solutions Architect</span>
                      <span className="text-[8px] bg-indigo-50 border border-indigo-100 px-1 py-0.2 rounded text-indigo-700 font-bold font-mono">TAMPER-PROOF</span>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[9px] text-slate-500">Issuer: Amazon Web Services</p>
                      <p className="text-[8px] font-mono text-slate-400 bg-slate-50 px-1 rounded select-all py-0.5 truncate">Hash: 0x8f3c7d9a1e0b5c4f2a7d8e9c...</p>
                    </div>
                    <div className="flex justify-between items-center text-[9px] pt-1 border-t border-slate-100">
                      <span className="text-emerald-600 font-semibold flex items-center">✓ Cryptographically Authentic</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900 text-white rounded-xl p-4 border border-slate-800 flex items-center justify-between" id="how-mock-cta-banner">
                  <div className="space-y-1">
                    <h4 className="text-xs font-bold text-indigo-300">Are you an Employer?</h4>
                    <p className="text-[10px] text-slate-400">Instantly search verified talent pool without intermediate agencies.</p>
                  </div>
                  <button
                    onClick={onEmployerSearch}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg transition-all shrink-0 shadow-md shadow-indigo-950"
                  >
                    Employer Directory
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* CTA section */}
      <section className="bg-indigo-900 py-16 text-white text-center relative overflow-hidden" id="cta-section">
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-800/50 rounded-full blur-3xl -z-10" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-violet-800/40 rounded-full blur-3xl -z-10" />
        
        <div className="max-w-4xl mx-auto px-4 space-y-6">
          <h2 className="text-3xl font-sans font-extrabold tracking-tight">Create Your Verified Smart Skill Passport Today</h2>
          <p className="text-indigo-100 max-w-xl mx-auto font-sans font-light">
            Ditch outdated resume forms. Build a beautiful, portable, and certified profile that proves your true capabilities.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
            <button
              onClick={onStartOnboarding}
              className="w-full sm:w-auto px-8 py-3 bg-white hover:bg-indigo-50 text-indigo-900 font-bold rounded-xl transition-all shadow-lg shadow-indigo-950/20"
              id="cta-bottom-signup"
            >
              Sign Up For Free
            </button>
            <button
              onClick={onExploreFeatures}
              className="w-full sm:w-auto px-8 py-3 bg-indigo-800 hover:bg-indigo-750 text-indigo-100 border border-indigo-700 rounded-xl transition-all font-semibold"
              id="cta-bottom-learn"
            >
              Learn More
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
