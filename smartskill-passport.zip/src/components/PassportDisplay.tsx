import React, { useState } from 'react';
import { Award, Briefcase, GraduationCap, Code, Link as LinkIcon, Mail, MapPin, Calendar, CheckCircle2, ShieldAlert, Share2, Clipboard, ShieldCheck, Download, ExternalLink } from 'lucide-react';
import { UserProfile, Skill, Certificate, Experience, Education, Project } from '../types';

interface PassportDisplayProps {
  profile: UserProfile;
  isOwnProfile?: boolean;
  onEditToggle?: () => void;
}

export default function PassportDisplay({
  profile,
  isOwnProfile = false,
  onEditToggle
}: PassportDisplayProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'skills' | 'timeline' | 'projects'>('all');
  const [copied, setCopied] = useState(false);

  const handleShareLink = () => {
    const url = `${window.location.origin}/passport/${profile.id}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const totalSkills = profile.skills.length;
  const verifiedSkills = profile.skills.filter(s => s.verified).length;
  const verificationRate = totalSkills > 0 ? Math.round((verifiedSkills / totalSkills) * 100) : 0;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10" id="passport-display-root">
      
      {/* Back button or Admin edit button if own profile */}
      {isOwnProfile && (
        <div className="flex justify-end mb-6" id="passport-admin-controls">
          <button
            onClick={onEditToggle}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-lg shadow-sm transition-all"
            id="passport-edit-trigger"
          >
            Edit Passport Details
          </button>
        </div>
      )}

      {/* Main Passport Visual Card */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xl overflow-hidden relative" id="passport-card-container">
        
        {/* Passport Header Banner Accent */}
        <div className="h-4 bg-gradient-to-r from-indigo-600 via-indigo-500 to-violet-600 w-full" />
        
        <div className="p-6 sm:p-10" id="passport-card-content">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* Left Side: Avatar, Basic Bio, Metadata */}
            <div className="lg:col-span-4 text-center lg:text-left space-y-6 lg:border-r lg:border-slate-100 lg:pr-8" id="passport-left-column">
              
              {/* Avatar and Security Ring */}
              <div className="relative inline-block" id="passport-avatar-wrapper">
                <div className="w-28 h-28 rounded-2xl mx-auto lg:mx-0 overflow-hidden ring-4 ring-indigo-50 p-1 bg-white shadow-md">
                  <img
                    src={profile.avatarUrl || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200'}
                    alt={profile.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover rounded-xl"
                  />
                </div>
                <div className="absolute -bottom-2 -right-2 bg-emerald-500 text-white p-1.5 rounded-xl shadow-lg border-2 border-white flex items-center justify-center" title="Verified Passport Active">
                  <ShieldCheck className="w-4 h-4" />
                </div>
              </div>

              {/* Name & Title */}
              <div className="space-y-2" id="passport-user-identity">
                <h2 className="text-2xl font-sans font-extrabold text-slate-900 tracking-tight leading-tight">{profile.name}</h2>
                <p className="text-sm font-medium text-indigo-600">{profile.headline}</p>
                <div className="flex flex-wrap justify-center lg:justify-start gap-3 pt-1 text-xs font-mono text-slate-500" id="user-geo-meta">
                  <span className="flex items-center"><MapPin className="w-3.5 h-3.5 mr-1" /> {profile.location}</span>
                  <span className="flex items-center"><Calendar className="w-3.5 h-3.5 mr-1" /> Joined {profile.joinedDate}</span>
                </div>
              </div>

              {/* Verified Rate Progress Bar */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/50 space-y-2" id="passport-verif-meter">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-semibold text-slate-700">Verification Index</span>
                  <span className="font-mono text-emerald-600 font-bold">{verificationRate}% Verified</span>
                </div>
                <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full transition-all" style={{ width: `${verificationRate}%` }} />
                </div>
                <p className="text-[10px] text-slate-500">
                  {verifiedSkills} of {totalSkills} core competencies linked to tamper-proof credentials.
                </p>
              </div>

              {/* Passport Bio */}
              <div className="space-y-1.5 text-left" id="passport-bio-wrapper">
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">BIOGRAPHY</span>
                <p className="text-xs text-slate-600 leading-relaxed font-sans">{profile.bio}</p>
              </div>

              {/* Contact Information */}
              {profile.privacySettings.showContact && (
                <div className="space-y-1.5 text-left pt-2 border-t border-slate-100" id="passport-contact-section">
                  <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">CONTACT PORTAL</span>
                  <div className="flex items-center text-xs text-slate-600 space-x-2" id="user-direct-mail">
                    <Mail className="w-3.5 h-3.5 text-slate-400" />
                    <span className="truncate select-all">{profile.email}</span>
                  </div>
                </div>
              )}

              {/* Sharing & QR Panel */}
              <div className="space-y-3 pt-4 border-t border-slate-100 text-left" id="passport-share-panel">
                <span className="text-[10px] uppercase font-mono tracking-wider text-slate-400">SHARE SECURE PASSPORT</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleShareLink}
                    className="px-3 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold rounded-lg border border-indigo-100 transition-all flex items-center justify-center space-x-1.5"
                  >
                    {copied ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Copied Link</span>
                      </>
                    ) : (
                      <>
                        <Clipboard className="w-3.5 h-3.5" />
                        <span>Copy Link</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => {
                      alert("Decentralized QR Passport is saved to downloads folder (Simulation)");
                    }}
                    className="px-3 py-2 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg border border-slate-200 transition-all flex items-center justify-center space-x-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Get QR Badge</span>
                  </button>
                </div>
              </div>

            </div>

            {/* Right Side: Navigation Tabs, Detailed Inventory, Experiences, projects */}
            <div className="lg:col-span-8 space-y-6" id="passport-right-column">
              
              {/* Tab Selector */}
              <div className="flex border-b border-slate-200 overflow-x-auto scrollbar-none" id="passport-tabs">
                {(['all', 'skills', 'timeline', 'projects'] as const).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    id={`passport-tab-btn-${tab}`}
                    className={`py-3 px-4 text-sm font-semibold tracking-wide capitalize shrink-0 border-b-2 transition-all -mb-[2px] ${
                      activeTab === tab
                        ? 'border-indigo-600 text-indigo-600 font-bold'
                        : 'border-transparent text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    {tab === 'all' ? 'Passport Hub' : tab === 'timeline' ? 'Career Timeline' : tab}
                  </button>
                ))}
              </div>

              {/* TAB CONTENT: SKILLS & CERTIFICATES */}
              {(activeTab === 'all' || activeTab === 'skills') && (
                <div className="space-y-6" id="passport-skills-tab">
                  <div>
                    <h3 className="text-base font-sans font-extrabold text-slate-900 flex items-center mb-4">
                      <Award className="w-5 h-5 text-indigo-600 mr-2" />
                      Skills Inventory & Verification
                    </h3>

                    {/* Skill Cards Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3" id="skills-cards-wrapper">
                      {profile.skills.map((skill) => (
                        <div
                          key={skill.id}
                          className="bg-white p-4 rounded-xl border border-slate-200/60 shadow-inner flex flex-col justify-between"
                          id={`skill-card-${skill.id}`}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <span className={`text-[9px] uppercase px-1.5 py-0.5 rounded font-mono font-bold ${
                                skill.category === 'technical' ? 'bg-indigo-50 text-indigo-700' : 'bg-slate-100 text-slate-700'
                              }`}>
                                {skill.category}
                              </span>
                              <h4 className="text-sm font-bold text-slate-900 mt-1.5">{skill.name}</h4>
                            </div>
                            
                            {skill.verified ? (
                              <span className="flex items-center text-[10px] font-bold text-emerald-600 bg-emerald-50 border border-emerald-200/50 px-1.5 py-0.5 rounded-full">
                                <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                                Verified
                              </span>
                            ) : (
                              <span className="flex items-center text-[10px] font-medium text-slate-500 bg-slate-50 px-1.5 py-0.5 rounded-full">
                                Pending Cert
                              </span>
                            )}
                          </div>

                          <div className="mt-3 space-y-1.5">
                            <div className="flex justify-between text-xs text-slate-500 font-medium">
                              <span>Skill Level: {skill.level}</span>
                              <span>{skill.yearsOfExperience} yrs exp</span>
                            </div>
                            <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                              <div className={`h-full rounded-full ${
                                skill.level === 'Expert' ? 'bg-indigo-600 w-full' : skill.level === 'Intermediate' ? 'bg-indigo-400 w-2/3' : 'bg-indigo-200 w-1/3'
                              }`} />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Certifications Subsection */}
                  <div>
                    <h3 className="text-base font-sans font-extrabold text-slate-900 flex items-center mb-4">
                      <ShieldCheck className="w-5 h-5 text-indigo-600 mr-2" />
                      Cryptographically Verified Certifications
                    </h3>

                    {profile.certificates.length === 0 ? (
                      <div className="p-6 text-center border-2 border-dashed border-slate-200 rounded-xl text-slate-500">
                        No certifications linked to this passport yet.
                      </div>
                    ) : (
                      <div className="space-y-4" id="certs-list-wrapper">
                        {profile.certificates.map((cert) => (
                          <div
                            key={cert.id}
                            className="bg-slate-50 p-4 rounded-xl border border-slate-200/60 shadow-sm relative overflow-hidden"
                            id={`cert-item-${cert.id}`}
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-0">
                              <div>
                                <h4 className="text-sm font-bold text-slate-900">{cert.title}</h4>
                                <p className="text-xs text-slate-500">Issuer: {cert.issuer} • Issued: {cert.issueDate}</p>
                              </div>

                              <span className="inline-flex items-center self-start sm:self-center text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-full font-mono">
                                <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                                {cert.verifiedStatus}
                              </span>
                            </div>

                            {/* Blockchain Verification Proof */}
                            <div className="mt-3 bg-white p-2 rounded-lg border border-slate-200/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1 sm:gap-4 text-[10px] font-mono">
                              <div className="truncate max-w-[280px] sm:max-w-md">
                                <span className="text-slate-400 uppercase font-semibold">Ledger Hash: </span>
                                <span className="text-indigo-600 select-all">{cert.txHash}</span>
                              </div>
                              {cert.credentialUrl && (
                                <a
                                  href={cert.credentialUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-indigo-600 font-semibold flex items-center shrink-0 hover:underline"
                                >
                                  Official Link
                                  <ExternalLink className="w-3 h-3 ml-1" />
                                </a>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB CONTENT: TIMELINE */}
              {(activeTab === 'all' || activeTab === 'timeline') && (
                <div className="space-y-6" id="passport-timeline-tab">
                  {/* Experience Timeline */}
                  <div>
                    <h3 className="text-base font-sans font-extrabold text-slate-900 flex items-center mb-6">
                      <Briefcase className="w-5 h-5 text-indigo-600 mr-2" />
                      Work Experience History
                    </h3>

                    {profile.experience.length === 0 ? (
                      <div className="p-6 text-center border-2 border-dashed border-slate-200 rounded-xl text-slate-500">
                        No work experience logged on this passport yet.
                      </div>
                    ) : (
                      <div className="relative pl-6 border-l-2 border-slate-200 space-y-8" id="experience-timeline">
                        {profile.experience.map((exp) => (
                          <div key={exp.id} className="relative" id={`timeline-item-${exp.id}`}>
                            {/* Dot */}
                            <span className="absolute -left-[31px] top-1 flex h-4 w-4 items-center justify-center rounded-full bg-white border-2 border-indigo-600 ring-4 ring-white shadow-sm" />
                            
                            <div className="space-y-1">
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                                <h4 className="text-sm font-bold text-slate-900">{exp.role}</h4>
                                <span className="text-xs font-medium text-slate-500 font-mono bg-slate-100 px-2 py-0.5 rounded">{exp.startDate} - {exp.endDate}</span>
                              </div>
                              <h5 className="text-xs font-semibold text-indigo-600">{exp.company}</h5>
                              <p className="text-xs text-slate-600 leading-relaxed font-sans pt-1">{exp.description}</p>
                              
                              <div className="flex flex-wrap gap-1 pt-2">
                                {exp.skillsUsed.map((sk) => (
                                  <span key={sk} className="text-[9px] font-mono font-medium bg-indigo-50/50 text-indigo-700 px-1.5 py-0.2 rounded border border-indigo-100/30">
                                    {sk}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Education Timeline */}
                  <div className="pt-4 border-t border-slate-100">
                    <h3 className="text-base font-sans font-extrabold text-slate-900 flex items-center mb-6">
                      <GraduationCap className="w-5 h-5 text-indigo-600 mr-2" />
                      Education Background
                    </h3>

                    {profile.education.length === 0 ? (
                      <div className="p-6 text-center border-2 border-dashed border-slate-200 rounded-xl text-slate-500">
                        No education records logged.
                      </div>
                    ) : (
                      <div className="space-y-4" id="education-list">
                        {profile.education.map((edu) => (
                          <div
                            key={edu.id}
                            className="p-4 rounded-xl border border-slate-200/60 bg-white shadow-inner flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-0"
                            id={`education-item-${edu.id}`}
                          >
                            <div className="space-y-1">
                              <h4 className="text-sm font-bold text-slate-900">{edu.degree}</h4>
                              <p className="text-xs text-slate-500">{edu.school} • Field: {edu.field}</p>
                              {edu.grade && <p className="text-[10px] font-mono text-indigo-600">{edu.grade}</p>}
                            </div>

                            <div className="text-right sm:self-center">
                              <span className="text-xs font-medium font-mono text-slate-500 block">{edu.startDate} - {edu.endDate}</span>
                              {edu.verified && (
                                <span className="inline-flex items-center text-[9px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.2 rounded-full mt-1">
                                  ✓ Verified Org
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB CONTENT: PROJECTS */}
              {(activeTab === 'all' || activeTab === 'projects') && (
                <div className="space-y-4" id="passport-projects-tab">
                  <h3 className="text-base font-sans font-extrabold text-slate-900 flex items-center mb-2">
                    <Code className="w-5 h-5 text-indigo-600 mr-2" />
                    Projects Portfolio & Proofs
                  </h3>

                  {profile.projects.length === 0 ? (
                    <div className="p-6 text-center border-2 border-dashed border-slate-200 rounded-xl text-slate-500">
                      No project files or portfolios connected yet.
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" id="projects-grid">
                      {profile.projects.map((proj) => (
                        <div
                          key={proj.id}
                          className="bg-white p-5 rounded-xl border border-slate-200/60 shadow-sm flex flex-col justify-between"
                          id={`proj-card-${proj.id}`}
                        >
                          <div className="space-y-2">
                            <h4 className="text-sm font-bold text-slate-900">{proj.title}</h4>
                            <p className="text-xs text-slate-600 leading-relaxed font-sans">{proj.description}</p>
                          </div>

                          <div className="mt-4 space-y-3">
                            <div className="flex flex-wrap gap-1">
                              {proj.skillsUsed.map((sk) => (
                                <span key={sk} className="text-[9px] font-mono bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded">
                                  {sk}
                                </span>
                              ))}
                            </div>

                            {proj.github && (
                              <div className="flex items-center text-[10px] font-mono text-indigo-600 pt-1 border-t border-slate-100">
                                <LinkIcon className="w-3.5 h-3.5 mr-1" />
                                <a href={`https://${proj.github}`} target="_blank" rel="noopener noreferrer" className="hover:underline truncate">
                                  {proj.github}
                                </a>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

            </div>

          </div>
        </div>
      </div>

    </div>
  );
}
